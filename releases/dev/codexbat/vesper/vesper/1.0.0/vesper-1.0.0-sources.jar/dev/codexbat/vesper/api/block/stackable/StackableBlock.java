package dev.codexbat.vesper.api.block.stackable;

import net.minecraft.class_1750;
import net.minecraft.class_2237;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;

public abstract class StackableBlock extends class_2237 implements StackCountAccess {
    public static final class_2758 STACK_COUNT = class_2758.method_11867("stack_count", 1, 64);

    private final int minStackCount;
    private final int maxStackCount;
    private final int defaultStackCount;
    private final StackDecayConfig decayConfig;

    protected StackableBlock(class_2251 settings,
                             int minStackCount,
                             int maxStackCount,
                             int defaultStackCount,
                             StackDecayConfig decayConfig) {
        super(settings);
        this.minStackCount = minStackCount;
        this.maxStackCount = maxStackCount;
        this.defaultStackCount = Math.max(minStackCount, Math.min(maxStackCount, defaultStackCount));
        this.decayConfig = decayConfig;
        this.method_9590(this.field_10647.method_11664().method_11657(STACK_COUNT, this.defaultStackCount));
    }

    @Override
    public class_2758 vesper$getStackCountProperty() {
        return STACK_COUNT;
    }

    @Override
    public int vesper$getMinStackCount() {
        return minStackCount;
    }

    @Override
    public int vesper$getMaxStackCount() {
        return maxStackCount;
    }

    public StackDecayConfig vesper$getDecayConfig(class_2680 state) {
        return decayConfig;
    }

    @Override
    protected void method_9515(class_2689.class_2690<net.minecraft.class_2248, class_2680> builder) {
        builder.method_11667(STACK_COUNT);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(STACK_COUNT, defaultStackCount);
    }
}