package dev.codexbat.vesper.api.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

/**

 Worldgen datagen base for scatter definitions.
 Subclasses should turn ScatterWorldgenSpec objects into the actual

 configured/placed feature registrations used by the mod.
 */
public abstract class VesperScatterWorldgenProvider extends FabricDynamicRegistryProvider {

    protected VesperScatterWorldgenProvider(FabricDataOutput output,
                                            CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected final void configure(class_7225.class_7874 registries, Entries entries) {
        generateScatterWorldgen(registries, entries);
    }

    protected abstract void generateScatterWorldgen(class_7225.class_7874 registries, Entries entries);

    @Override
    public abstract String method_10321();
}