package dev.codexbat.vesper.client.mixin.glint;

import dev.codexbat.vesper.api.glint.GlintDefinition;
import dev.codexbat.vesper.api.glint.VesperGlintRegistry;
import dev.codexbat.vesper.client.glint.internal.render.AmbientParticleManager;
import dev.codexbat.vesper.client.glint.internal.render.SparkleParticleManager;
import dev.codexbat.vesper.client.glint.internal.render.TrailParticleManager;
import dev.codexbat.vesper.api.glint.type.AmbientGlint;
import dev.codexbat.vesper.api.glint.type.SparkleGlint;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_9779;

/**
 * Hooks {@link class_329} to drive ambient and sparkle particle effects for
 * hotbar items while the player is in the world.
 *
 * <h2>Responsibilities:</h2>
 * <ul>
 *   <li><strong>Spawn</strong> — each frame, for every hotbar slot holding an
 *       {@link AmbientGlint} or {@link SparkleGlint} item, particles are spawned
 *       at that slot's screen-space centre. This runs unconditionally so hotbar
 *       sparkles are visible even when an inventory screen is open on top.</li>
 *   <li><strong>Tick + Render</strong> — advances physics and draws particles,
 *       but <em>only when no screen is currently open</em>. When an inventory
 *       screen is open, {@code HandledScreenMixin} owns the tick/render cycle,
 *       preventing the managers from being advanced twice per frame.</li>
 * </ul>
 *
 * <h2>Hotbar slot geometry:</h2>
 * <p>Vanilla draws the hotbar background at
 * {@code x = scaledWidth/2 - 91, y = scaledHeight - 22}.
 * Each of the 9 slots is 20 px wide; item icons have a 3 px inset from the
 * slot edge, giving an icon left edge at {@code slotX + 3} and a centre at
 * {@code slotX + 3 + 8 = slotX + 11}, i.e.
 * {@code scaledWidth/2 - 91 + slot*20 + 11 = scaledWidth/2 - 80 + slot*20}.
 * Vertically, the 16 px icon sits 3 px from the top of the 22 px bar, so the
 * centre is at {@code scaledHeight - 22 + 3 + 8 = scaledHeight - 11}.
 */
@Mixin(class_329.class)
public class InGameHudMixin {

    @Shadow @Final private class_310 client;

    /**
     * Runs at the tail of every HUD render.
     *
     * <p>Particle spawning always occurs for hotbar slots.
     * Ticking and rendering only occur when no screen is open —
     * if a screen is open, {@code HandledScreenMixin} handles those steps.
     */
    @Inject(method = "render", at = @At("TAIL"))
    private void vesper$renderHotbarParticles(
            class_332 context, class_9779 tickCounter, CallbackInfo ci) {

        if (client.field_1724 == null) return;

        int screenWidth  = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        // HandledScreen (inventory, chest, etc.) → HandledScreenMixin owns tick/render.
        // Any other screen (chat, social interactions, etc.) → we still own tick/render,
        // but dim the hotbar particles since the UI overlaps that area.
        boolean handledOpen = client.field_1755 instanceof class_465;
        boolean otherOpen   = client.field_1755 != null && !handledOpen;

        float hotbarAlpha = handledOpen ? 0.3f
                : otherOpen   ? 0.6f
                :               1.0f;

        class_1661 inventory = client.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;

            Optional<GlintDefinition> glint = VesperGlintRegistry.getGlint(stack.method_7909());
            if (glint.isEmpty()) continue;

            double slotCx = screenWidth  / 2.0 - 80 + i * 20;
            double slotCy = screenHeight - 11.0;

            GlintDefinition def = glint.get();
            if (def instanceof AmbientGlint ambient) {
                AmbientParticleManager.spawn(slotCx, slotCy, ambient.getConfig(), hotbarAlpha);
            } else if (def instanceof SparkleGlint sparkle) {
                SparkleParticleManager.spawn(slotCx, slotCy, sparkle.getIdleConfig(), hotbarAlpha);
            }
        }

        // Skip if a HandledScreen is open — it owns the tick/render cycle.
        if (!handledOpen) {
            TrailParticleManager.tick();
            TrailParticleManager.render(context);

            AmbientParticleManager.tick();
            AmbientParticleManager.render(context);

            SparkleParticleManager.tick();
            SparkleParticleManager.render(context);
        }
    }
}