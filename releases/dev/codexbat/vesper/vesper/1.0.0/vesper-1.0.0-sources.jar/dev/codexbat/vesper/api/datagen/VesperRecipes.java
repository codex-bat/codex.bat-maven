package dev.codexbat.vesper.api.datagen;

import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2096;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_8790;
import org.jspecify.annotations.Nullable;

public final class VesperRecipes {

    private final class_2446 generator;
    private final class_8790 exporter;
    private final class_7225.class_7874 registries;

    VesperRecipes(class_2446 generator,
                  class_8790 exporter,
                  class_7225.class_7874 registries) {
        this.generator = generator;
        this.exporter = exporter;
        this.registries = registries;
    }

    public class_7225.class_7874 registries() {
        return registries;
    }

    public class_7871<class_1792> items() {
        return registries.method_46762(class_7924.field_41197);
    }

    public class_5321<class_1860<?>> recipeKey(class_2960 id) {
        return class_5321.method_29179(class_7924.field_52178, id);
    }

    public class_175<class_2066.class_2068> conditionsFromItem(class_1935 item) {
        return generator.method_10426(item);
    }

    public class_175<class_2066.class_2068> conditionsFromItem(class_2096.class_2100 count,
                                                                                         class_1935 item) {
        return generator.method_35914(count, item);
    }

    public class_175<class_2066.class_2068> conditionsFromTag(class_6862<class_1792> tag) {
        return generator.method_10420(tag);
    }

    public class_1856 ingredientFromTag(class_6862<class_1792> tag) {
        return generator.method_62748(tag);
    }

    public ShapelessBuilder shapeless(class_1935 output) {
        return new ShapelessBuilder(generator.method_62749(class_7800.field_40642, output), exporter);
    }

    public ShapelessBuilder shapeless(class_1935 output, int count) {
        return new ShapelessBuilder(generator.method_62750(class_7800.field_40642, output, count), exporter);
    }

    public ShapelessBuilder shapeless(class_7800 category, class_1935 output) {
        return new ShapelessBuilder(generator.method_62749(category, output), exporter);
    }

    public ShapelessBuilder shapeless(class_7800 category, class_1935 output, int count) {
        return new ShapelessBuilder(generator.method_62750(category, output, count), exporter);
    }

    public ShapelessBuilder shapeless(class_7800 category, class_1799 output) {
        return new ShapelessBuilder(generator.method_62745(category, output), exporter);
    }

    public ShapedBuilder shaped(class_1935 output) {
        return new ShapedBuilder(generator.method_62746(class_7800.field_40642, output), exporter);
    }

    public ShapedBuilder shaped(class_1935 output, int count) {
        return new ShapedBuilder(generator.method_62747(class_7800.field_40642, output, count), exporter);
    }

    public ShapedBuilder shaped(class_7800 category, class_1935 output) {
        return new ShapedBuilder(generator.method_62746(category, output), exporter);
    }

    public ShapedBuilder shaped(class_7800 category, class_1935 output, int count) {
        return new ShapedBuilder(generator.method_62747(category, output, count), exporter);
    }

    public static final class ShapelessBuilder {
        private final class_2450 delegate;
        private final class_8790 exporter;

        private ShapelessBuilder(class_2450 delegate, class_8790 exporter) {
            this.delegate = delegate;
            this.exporter = exporter;
        }

        public ShapelessBuilder input(class_1935 item) {
            delegate.method_10454(item);
            return this;
        }

        public ShapelessBuilder input(class_1935 item, int amount) {
            delegate.method_10449(item, amount);
            return this;
        }

        public ShapelessBuilder input(class_1856 ingredient) {
            delegate.method_10451(ingredient);
            return this;
        }

        public ShapelessBuilder input(class_1856 ingredient, int amount) {
            delegate.method_10453(ingredient, amount);
            return this;
        }

        public ShapelessBuilder input(CustomIngredient ingredient) {
            delegate.method_10451(ingredient.toVanilla());
            return this;
        }

        public ShapelessBuilder input(CustomIngredient ingredient, int amount) {
            delegate.method_10453(ingredient.toVanilla(), amount);
            return this;
        }

        public ShapelessBuilder criterion(String name, class_175<?> criterion) {
            delegate.method_10442(name, criterion);
            return this;
        }

        public ShapelessBuilder group(@Nullable String group) {
            delegate.method_10452(group);
            return this;
        }

        public void save(class_2960 id) {
            delegate.method_17972(exporter, class_5321.method_29179(class_7924.field_52178, id));
        }

        public void save(class_5321<class_1860<?>> key) {
            delegate.method_17972(exporter, key);
        }
    }

    public static final class ShapedBuilder {
        private final class_2447 delegate;
        private final class_8790 exporter;

        private ShapedBuilder(class_2447 delegate, class_8790 exporter) {
            this.delegate = delegate;
            this.exporter = exporter;
        }

        public ShapedBuilder input(char symbol, class_1935 item) {
            delegate.method_10434(symbol, item);
            return this;
        }

        public ShapedBuilder input(char symbol, class_1856 ingredient) {
            delegate.method_10428(symbol, ingredient);
            return this;
        }

        public ShapedBuilder input(char symbol, CustomIngredient ingredient) {
            delegate.method_10428(symbol, ingredient.toVanilla());
            return this;
        }

        public ShapedBuilder input(char symbol, class_6862<class_1792> tag) {
            delegate.method_10433(symbol, tag);
            return this;
        }

        public ShapedBuilder pattern(String pattern) {
            delegate.method_10439(pattern);
            return this;
        }

        public ShapedBuilder criterion(String name, class_175<?> criterion) {
            delegate.method_10429(name, criterion);
            return this;
        }

        public ShapedBuilder group(@Nullable String group) {
            delegate.method_10435(group);
            return this;
        }

        public ShapedBuilder showNotification(boolean showNotification) {
            delegate.method_49380(showNotification);
            return this;
        }

        public void save(class_2960 id) {
            delegate.method_17972(exporter, class_5321.method_29179(class_7924.field_52178, id));
        }

        public void save(class_5321<class_1860<?>> key) {
            delegate.method_17972(exporter, key);
        }
    }
}