package dev.codexbat.vesper.datagen.provider;

import dev.codexbat.vesper.Vesper;
import dev.codexbat.vesper.api.datagen.VesperRecipeProvider;
import dev.codexbat.vesper.api.datagen.VesperRecipes;
import dev.codexbat.vesper.api.recipe.ComponentIngredient;
import dev.codexbat.vesper.plush.PlushyRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7446;
import net.minecraft.class_7924;
import net.minecraft.class_9307;
import net.minecraft.class_9334;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Generates crafting recipes for Vesper's built-in content.
 */
@SuppressWarnings("unused")
public final class ModRecipeProvider extends VesperRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output,
                             CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void buildRecipes(VesperRecipes recipes) {
        addCodexPlushRecipe(recipes);
    }

    private void addCodexPlushRecipe(VesperRecipes recipes) {
        var patternLookup = recipes.registries().method_46762(class_7924.field_41252);

        class_1799 banner = new class_1799(class_1802.field_8572);
        banner.method_57379(class_9334.field_49619, new class_9307(List.of(
                new class_9307.class_9308(patternLookup.method_46747(class_7446.field_39147),         class_1767.field_7944),
                new class_9307.class_9308(patternLookup.method_46747(class_7446.field_39176),       class_1767.field_7963),
                new class_9307.class_9308(patternLookup.method_46747(class_7446.field_39161), class_1767.field_7963),
                new class_9307.class_9308(patternLookup.method_46747(class_7446.field_39150),        class_1767.field_7944)
        )));

        recipes.shapeless(PlushyRegistry.getItem(Vesper.id("codex_plush")))
                .input(class_1802.field_19059)
                .input(ComponentIngredient.of(banner))
                .criterion("has_banner", recipes.conditionsFromItem(class_1802.field_8572))
                .save(Vesper.id("codex_plush"));
    }

    @Override
    public String method_10321() {
        return "Vesper Recipe Provider";
    }
}