package dev.codexbat.vesper.client.plush;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

/**
 * Renders a single PlushyCuboid by emitting six quads (skipping null faces)
 * directly into a VertexConsumer.
 *
 * UV convention: [u0,v0] is the top-left corner of the texture rectangle,
 * [u1,v1] is the bottom-right. Reversed UV (u0 > u1) mirrors that face —
 * handled automatically by passing the values through unmodified.
 */
public final class PlushyCuboidRenderer {

    /** 1 pixel = 1/16 of a block. */
    private static final float S = 1f / 16f;

    public static void render(class_4587 ms, class_4588 vc, PlushyCuboid c, int light, int overlay) {
        ms.method_22903();

        // Apply this element's own Euler rotation around its pivot
        if (c.rotX() != 0 || c.rotY() != 0 || c.rotZ() != 0) {
            float px = c.pivX() * S, py = c.pivY() * S, pz = c.pivZ() * S;
            ms.method_46416(px, py, pz);
            if (c.rotX() != 0) ms.method_22907(class_7833.field_40714.rotationDegrees(c.rotX()));
            if (c.rotY() != 0) ms.method_22907(class_7833.field_40716.rotationDegrees(c.rotY()));
            if (c.rotZ() != 0) ms.method_22907(class_7833.field_40718.rotationDegrees(c.rotZ()));
            ms.method_46416(-px, -py, -pz);
        }

        float x1 = c.x1() * S, y1 = c.y1() * S, z1 = c.z1() * S;
        float x2 = c.x2() * S, y2 = c.y2() * S, z2 = c.z2() * S;
        class_4587.class_4665 e = ms.method_23760();

        // Each face: 4 vertices in CCW order when viewed from outside.
        // Vertex layout → UV layout: v0=top-right, v1=top-left, v2=bot-left, v3=bot-right
        // UV: (u1,v0) (u0,v0) (u0,v1) (u1,v1)
        if (c.north() != null) quad(e,vc, c.north(), 0, 0,-1, light,overlay, x2,y2,z1, x1,y2,z1, x1,y1,z1, x2,y1,z1);
        if (c.south() != null) quad(e,vc, c.south(), 0, 0, 1, light,overlay, x1,y2,z2, x2,y2,z2, x2,y1,z2, x1,y1,z2);
        if (c.east() != null) quad(e,vc, c.east(), 1, 0, 0, light,overlay, x2,y2,z2, x2,y2,z1, x2,y1,z1, x2,y1,z2);
        if (c.west() != null) quad(e,vc, c.west(), -1, 0, 0, light,overlay, x1,y2,z1, x1,y2,z2, x1,y1,z2, x1,y1,z1);
        if (c.up() != null) quad(e,vc, c.up(), 0, 1, 0, light,overlay, x2,y2,z1, x1,y2,z1, x1,y2,z2, x2,y2,z2);
        if (c.down() != null) quad(e,vc, c.down(), 0,-1, 0, light,overlay, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2);

        ms.method_22909();
    }

    private static void quad(class_4587.class_4665 e, class_4588 vc, FaceUV uv, float nx, float ny, float nz, int light, int overlay, float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3) {
        // UV from 0-16 Blockbench space → 0-1 texture coords
        float u0 = uv.u0() / 16f, v0 = uv.v0() / 16f;
        float u1 = uv.u1() / 16f, v1 = uv.v1() / 16f;
        Matrix4f pm = e.method_23761();
        vc.method_22918(pm,x0,y0,z0).method_1336(255,255,255,255).method_22913(u1,v0).method_22922(overlay).method_60803(light).method_60831(e,nx,ny,nz);
        vc.method_22918(pm,x1,y1,z1).method_1336(255,255,255,255).method_22913(u0,v0).method_22922(overlay).method_60803(light).method_60831(e,nx,ny,nz);
        vc.method_22918(pm,x2,y2,z2).method_1336(255,255,255,255).method_22913(u0,v1).method_22922(overlay).method_60803(light).method_60831(e,nx,ny,nz);
        vc.method_22918(pm,x3,y3,z3).method_1336(255,255,255,255).method_22913(u1,v1).method_22922(overlay).method_60803(light).method_60831(e,nx,ny,nz);
    }
}