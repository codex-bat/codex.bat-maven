package dev.codexbat.vesper.api.blockentity;

import dev.codexbat.vesper.api.util.scatter.StackableScatterState;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public abstract class StackableBlockEntity extends class_2586 implements StackableScatterState {
    private boolean scatterPaused;
    private boolean fragile;
    private int scatterCooldown;

    protected StackableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Override
    public boolean vesper$isScatterPaused() {
        return scatterPaused;
    }

    @Override
    public void vesper$setScatterPaused(boolean paused) {
        this.scatterPaused = paused;
        this.method_5431();
    }

    @Override
    public boolean vesper$isFragile() {
        return fragile;
    }

    @Override
    public void vesper$setFragile(boolean fragile) {
        this.fragile = fragile;
        this.method_5431();
    }

    @Override
    public int vesper$getScatterCooldown() {
        return scatterCooldown;
    }

    @Override
    public void vesper$setScatterCooldown(int ticks) {
        this.scatterCooldown = Math.max(0, ticks);
        this.method_5431();
    }

    public static void tick(net.minecraft.class_1937 world,
                            class_2338 pos,
                            class_2680 state,
                            StackableBlockEntity be) {
        if (world.method_8608()) return;
        if (!(state.method_26204() instanceof dev.codexbat.vesper.api.block.stackable.StackableBlock stackable)) return;
        dev.codexbat.vesper.api.util.scatter.ScatterLogic.tick(world, pos, state, be, stackable);
    }
}