package dev.codexbat.vesper.client.plush;

import dev.codexbat.vesper.plush.PlushyDefinition;
import dev.codexbat.vesper.plush.entity.PlushyEntity;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public class PlushyEntityRenderer
        extends class_897<PlushyEntity, PlushyEntityRenderer.State> {

    /**
     * Final droop angle in degrees. The arm animation eases into this value.
     * Tune to 22.5f for a softer resting pose, or leave at 45f for a more
     * relaxed "arms hanging" look.
     */
    private static final float ARM_DROOP_DEG = 45f;
    private static final float BOB_AMPLITUDE = 0.04f;

    private static final class_2960 MISSING =
            class_2960.method_60655("minecraft", "textures/misc/missing.png");

    public PlushyEntityRenderer(class_5617.class_5618 ctx) {
        super(ctx);
        this.field_4673 = 0.3f;
    }

    // ── Render state ──────────────────────────────────────────────────────────

    public static final class State extends class_10017 {
        public float arm          = 0f;
        public float bob          = 0f;
        public float bodyYaw      = 0f;
        public float squishNorm   = 0f; // ← NEW: 0 = resting, 1 = full squish
        public class_2960 texture = null;
        public PlushyModelData model = null;
    }

    @Override public State method_55269() { return new State(); }

    @Override
    public void updateRenderState(PlushyEntity entity, State state, float tickProgress) {
        super.method_62354(entity, state, tickProgress);

        state.arm        = class_3532.method_16439(tickProgress, entity.prevArmProgress, entity.armProgress);
        state.bob        = class_3532.method_16439(tickProgress, entity.prevBobPhase,    entity.bobPhase);
        state.bodyYaw    = entity.method_60951(tickProgress);
        state.squishNorm = entity.getSquishNorm(); // ← NEW

        PlushyDefinition def = entity.getDefinition();
        if (def != null) {
            state.texture = def.getEntityTexture();
            state.model   = PlushyModelRegistry.get(def.getId());
        } else {
            state.texture = MISSING;
            state.model   = null;
        }
    }

    // ── Main render ───────────────────────────────────────────────────────────

    @Override
    public void render(State state, class_4587 ms,
                       class_11659 queue, class_12075 camera) {

        if (state.model != null && state.texture != null) {
            class_1921 layer = class_12249.method_75994(state.texture);
            class_4597.class_4598 immediate =
                    class_310.method_1551().method_22940().method_23000();
            class_4588 vc = immediate.method_73477(layer);
            ms.method_22903();

            // 1. Idle bob (muted until arms are down)
            ms.method_22904(0.0, (float) Math.sin(state.bob) * BOB_AMPLITUDE * state.arm, 0.0);

            // 2. Squish scale — ← NEW
            // Quadratic ease-out: snaps in hard at the moment of the click,
            // then releases quickly. Bottom of the model stays grounded because
            // the scale origin is the entity's foot position (Y = 0).
            if (state.squishNorm > 0f) {
                float t = state.squishNorm * state.squishNorm; // quadratic ease-out
                ms.method_22905(1f + 0.12f * t,   // +12 % wider
                        1f - 0.18f * t,   // −18 % shorter
                        1f + 0.12f * t);
                // Tune multipliers freely. At squishNorm = 1 (peak):
                //   scaleXZ = 1.12, scaleY = 0.82 — a clear but not violent squish.
            }

            // 3. Face the right direction (models export south-facing by default)
            ms.method_22907(class_7833.field_40716.rotationDegrees(180f - state.bodyYaw));

            // 4. Static bones
            for (PlushyBone bone : state.model.staticBones()) {
                ms.method_22903();
                for (PlushyCuboid cuboid : bone.cuboids()) {
                    PlushyCuboidRenderer.render(ms, vc, cuboid, state.field_61820, class_4608.field_21444);
                }
                ms.method_22909();
            }

            // 5. Arm bones
            renderArmBone(ms, vc, state.model.leftArmBone(),  state.arm, true,  state.field_61820);
            renderArmBone(ms, vc, state.model.rightArmBone(), state.arm, false, state.field_61820);

            ms.method_22909();
        }

        super.method_3936(state, ms, queue, camera); // shadow + nametag
    }

    // ── Per-arm animation ─────────────────────────────────────────────────────

    private void renderArmBone(class_4587 ms, class_4588 vc,
                               PlushyBone bone, float arm,
                               boolean isLeft, int light) {
        ms.method_22903();
        float px = bone.animPivX() / 16f;
        float py = bone.animPivY() / 16f;
        float pz = bone.animPivZ() / 16f;
        float angle = ARM_DROOP_DEG * arm;

        ms.method_46416(px, py, pz);
        ms.method_22907(isLeft
                ? class_7833.field_40718.rotationDegrees(angle)
                : class_7833.field_40717.rotationDegrees(angle));
        ms.method_46416(-px, -py, -pz);

        for (PlushyCuboid cuboid : bone.cuboids()) {
            PlushyCuboidRenderer.render(ms, vc, cuboid, light, class_4608.field_21444);
        }
        ms.method_22909();
    }
}