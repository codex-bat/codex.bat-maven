package dev.codexbat.vesper.api.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_1935;
import net.minecraft.class_201;
import net.minecraft.class_219;
import net.minecraft.class_2248;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;

/**
 * Abstract base class for block loot table providers. Extend this and implement
 * {@link #method_10379()}, then call the helpers below or any of the many methods
 * inherited from {@link FabricBlockLootTableProvider} / {@code BlockLootTableGenerator}.
 *
 * <p><b>Inherited helpers you'll use constantly:</b>
 * <ul>
 *   <li>{@code addDrop(block)} — block always drops itself</li>
 *   <li>{@code addDrop(block, item)} — block always drops {@code item}</li>
 *   <li>{@code addDropWithSilkTouch(block, drop)} — drops {@code drop} only with silk touch</li>
 *   <li>{@code addDropWithSilkTouchOrNormally(block, silkDrop, normalDrop)} — bifurcated drop</li>
 *   <li>{@code dropsNothing(block)} — block drops nothing</li>
 *   <li>{@code addDrop(block, builder)} — fully custom loot table</li>
 * </ul>
 *
 * <p><b>Vesper extras (defined below):</b>
 * <ul>
 *   <li>{@code dropCount(item, n)} — always drop exactly n of item</li>
 *   <li>{@code dropBetween(item, min, max)} — random count in range</li>
 *   <li>{@code dropWithChance(block, item, chance)} — drop item with a flat probability</li>
 * </ul>
 *
 * <p><b>Usage:</b>
 * <pre>
 * public class MyBlockLootProvider extends VesperBlockLootProvider {
 *     public MyBlockLootProvider(FabricDataOutput out, CompletableFuture&lt;...&gt; reg) {
 *         super(out, reg);
 *     }
 *
 *     {@literal @}Override
 *     public void generate() {
 *         addDrop(MyBlocks.OAK_CRATE);                            // drops itself
 *         addDrop(MyBlocks.ORE, MyItems.GEM);                     // always drops gem
 *         addDropWithSilkTouch(MyBlocks.GLASS_PANE, MyBlocks.GLASS_PANE);
 *         addDrop(MyBlocks.GRAVEL_BIN, dropBetween(Items.GRAVEL, 2, 6));
 *         dropWithChance(MyBlocks.RARE_ORE, MyItems.RARE_GEM, 0.15f); // 15% chance
 *     }
 * }
 * </pre>
 */
public abstract class VesperBlockLootProvider extends FabricBlockLootTableProvider {

    protected VesperBlockLootProvider(FabricDataOutput output,
                                      CompletableFuture<class_7225.class_7874> lookup) {
        super(output, lookup);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Vesper extra helpers
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * A loot table builder that always drops exactly {@code count} of {@code item},
     * respecting the "survives explosion" condition (i.e. TNT may not always yield drops).
     */
    protected class_52.class_53 dropCount(class_1935 item, int count) {
        return class_52.method_324()
                .method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(class_77.method_411(item)
                                .method_438(class_141.method_621(
                                        class_44.method_32448(count)))
                                .method_421(class_201.method_871())));
    }

    /**
     * A loot table builder that drops a random count of {@code item} between
     * {@code min} and {@code max} (inclusive, uniform distribution).
     */
    protected class_52.class_53 dropBetween(class_1935 item, float min, float max) {
        return class_52.method_324()
                .method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(class_77.method_411(item)
                                .method_438(class_141.method_621(
                                        class_5662.method_32462(min, max)))
                                .method_421(class_201.method_871())));
    }

    /**
     * Registers a loot table where {@code block} has a flat {@code chance}
     * (0.0–1.0) of dropping {@code item}.
     * <pre>
     * dropWithChance(MyBlocks.RARE_ORE, MyItems.RARE_GEM, 0.10f); // 10% drop
     * </pre>
     */
    protected void dropWithChance(class_2248 block, class_1935 item, float chance) {
        method_45988(block, class_52.method_324()
                .method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(class_77.method_411(item)
                                .method_421(class_219.method_932(chance))
                                .method_421(class_201.method_871()))));
    }
}