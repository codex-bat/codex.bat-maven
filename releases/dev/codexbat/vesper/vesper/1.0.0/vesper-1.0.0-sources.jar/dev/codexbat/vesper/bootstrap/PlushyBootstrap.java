package dev.codexbat.vesper.bootstrap;

import dev.codexbat.vesper.Vesper;
import dev.codexbat.vesper.plush.PlushyDefinition;
import dev.codexbat.vesper.plush.PlushyRegistry;
import dev.codexbat.vesper.plush.loot.PlushyDropLootFunction;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class PlushyBootstrap {
    private PlushyBootstrap() {}

    public static void initialize() {
        // PlushyRegistry - check that to see what this is all about
        PlushyRegistry.initialize();

        // Register plushy definitions – they automatically get an Item and become usable
        PlushyRegistry.register(
                PlushyDefinition.builder(
                                Vesper.id("codex_plush"),
                                Vesper.id("textures/entity/plush/codex.png")
                        )
                        .helmet()     // allowed slots (true)
                        .mainhand()
                        .offhand()
                        .build()
        );

        class_2378.method_10230(
                class_7923.field_41134,
                Vesper.id("plushy_drop"),
                PlushyDropLootFunction.TYPE
        );
    }
}
