package dev.codexbat.vesper.client.particle;

import com.mojang.serialization.MapCodec;
import dev.codexbat.vesper.client.glint.internal.render.WorldGlintParticleManager;
import dev.codexbat.vesper.client.glint.internal.render.WorldGlintParticleEffect;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2378;
import net.minecraft.class_2396;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Registers Vesper's custom {@link class_2396}s.
 *
 * <p>Calling {@link #register()} once from {@link ClientModInitializer}
 * <em>before</em> {@link WorldGlintParticleManager}
 * is used.
 *
 * <pre>{@code
 * @Override public void onInitializeClient() {
 *     VesperParticleTypes.register();
 *     WorldGlintParticleManager.registerFactory();
 * }
 * }</pre>
 *
 * <p>{@link net.minecraft.class_2396} is abstract in 1.21.11, so we
 * register an anonymous subclass that returns stub codecs.  The codecs are never
 * called because all particles are spawned client-side via
 * {@code ParticleManager.addParticle()} and are never sent over the network.
 */
@Environment(EnvType.CLIENT)
public final class VesperParticleTypes {

    /** The single particle type used for all world-space glint particles. */
    public static class_2396<WorldGlintParticleEffect> WORLD_GLINT;

    public static void register() {
        WORLD_GLINT = class_2378.method_10230(
                class_7923.field_41180,
                class_2960.method_60655("vesper", "world_glint"),
                new class_2396<WorldGlintParticleEffect>(false) {

                    @Override
                    public MapCodec<WorldGlintParticleEffect> method_29138() {
                        return WorldGlintParticleEffect.STUB_CODEC;
                    }

                    @Override
                    public class_9139<? super class_9129, WorldGlintParticleEffect> method_56179() {
                        return WorldGlintParticleEffect.STUB_PACKET_CODEC;
                    }
                }
        );
    }

    private VesperParticleTypes() {}
}