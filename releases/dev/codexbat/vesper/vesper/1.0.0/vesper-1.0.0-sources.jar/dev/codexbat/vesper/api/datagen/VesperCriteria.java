package dev.codexbat.vesper.api.datagen;

import net.minecraft.advancement.criterion.*;
import net.minecraft.class_1299;
import net.minecraft.class_174;
import net.minecraft.class_175;
import net.minecraft.class_179;
import net.minecraft.class_184;
import net.minecraft.class_1860;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_196;
import net.minecraft.class_1999;
import net.minecraft.class_2006;
import net.minecraft.class_2019;
import net.minecraft.class_2037;
import net.minecraft.class_2044;
import net.minecraft.class_2048;
import net.minecraft.class_2050;
import net.minecraft.class_2062;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2080;
import net.minecraft.class_2090;
import net.minecraft.class_2096;
import net.minecraft.class_2115;
import net.minecraft.class_2123;
import net.minecraft.class_2131;
import net.minecraft.class_2135;
import net.minecraft.class_2140;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4711;
import net.minecraft.class_5321;
import net.minecraft.class_6885;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_8508;
import java.util.Optional;

/**
 * Convenience factories for every common vanilla advancement criterion type.
 *
 * <p>Use inside a {@link VesperAdvancementProvider}:
 * <pre>
 * .criterion("get_diamond",  VesperCriteria.obtainItem(Items.DIAMOND))
 * .criterion("kill_zombie",  VesperCriteria.killEntity(EntityType.ZOMBIE))
 * .criterion("go_nether",    VesperCriteria.enterDimension(World.NETHER))
 * .criterion("never",        VesperCriteria.never())                // manually granted
 * .criterion("use_hoe",      VesperCriteria.useItemOnBlock(
 *       blockLookup, itemLookup, Blocks.DIRT,
 *       ItemPredicate.Builder.create().items(itemLookup, Items.WOODEN_HOE)))
 * .criterion("craft_table",  VesperCriteria.craftRecipe(RegistryKey.of(RegistryKeys.RECIPE, Identifier.of("crafting_table"))))
 * .criterion("shoot_arrow",  VesperCriteria.shootCrossbow(itemLookup, Items.ARROW))
 * </pre>
 *
 * <p><b>Note:</b> Some methods require {@link class_7871} parameters because
 * Minecraft 1.21.x uses registry entries directly. Pass the lookups from
 * {@code ProviderContext} (e.g. {@code context.getRegistries()}).
 */
public final class VesperCriteria {

    private VesperCriteria() {}

    // ═════════════════════════════════════════════════════════════════════════
    //  Items / Inventory
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player's inventory contains {@code item}. */
    public static class_175<class_2066.class_2068> obtainItem(
            class_1935 item) {
        return class_2066.class_2068.method_8959(item);
    }

    /** Fires when the inventory matches all supplied {@link class_2073}s. */
    public static class_175<class_2066.class_2068> obtainItem(
            class_2073... predicates) {
        return class_2066.class_2068.method_8957(predicates);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Entities — kills
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player kills an entity of the given type. */
    public static class_175<class_2080.class_2083> killEntity(
            class_1299<?> type) {
        return class_2080.class_2083.method_8997(
                class_2048.class_2049.method_8916()
                        .method_8917(new class_2050(class_6885.method_40246(type.method_40124())))
        );
    }

    /** Fires when the player kills any entity (no type filter). */
    public static class_175<class_2080.class_2083> killAnyEntity() {
        return class_2080.class_2083.method_8999();
    }

    /** Fires when the player is killed by an entity of the given type. */
    public static class_175<class_2080.class_2083> killedByEntity(
            class_1299<?> killerType) {
        return class_2080.class_2083.method_35251(
                class_2048.class_2049.method_8916()
                        .method_8917(new class_2050(class_6885.method_40246(killerType.method_40124())))
        );
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Entities — damage
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player deals damage to the given entity type. */
    public static class_175<class_2115.class_2117> hurtEntity(
            class_1299<?> type) {
        return class_2115.class_2117.method_35295(
                Optional.of(
                        class_2048.class_2049.method_8916()
                                .method_8917(new class_2050(class_6885.method_40246(type.method_40124())))
                                .method_8920()
                )
        );
    }

    /** Fires when the player receives damage from an entity of the given type. */
    public static class_175<class_2044.class_2046> hurtByEntity(
            class_1299<?> sourceType) {
        // EntityHurtPlayerCriterion uses DamagePredicate, not a direct entity predicate
        class_2019.class_2020 damageBuilder = class_2019.class_2020.method_8844()
                .method_35117(class_2048.class_2049.method_8916()
                        .method_8917(new class_2050(class_6885.method_40246(sourceType.method_40124()))).method_8920());
        return class_2044.class_2046.method_8908(damageBuilder);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Blocks
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player places the given block. */
    public static class_175<class_4711.class_4712> placeBlock(class_2248 block) {
        return class_4711.class_4712.method_51710(block);
    }

    /** Fires when the player enters (stands inside) the given block. */
    public static class_175<class_2037.class_2039> enterBlock(class_2248 block) {
        return class_2037.class_2039.method_8890(block);
    }

    /**
     * Fires when an item is used on the given block.
     *
     * @param blockLookup the block registry lookup (from the provider context)
     * @param itemLookup  the item registry lookup (from the provider context)
     * @param block       the targeted block
     * @param item        an {@code ItemPredicate.Builder} describing the used item
     */
    public static class_175<class_4711.class_4712> useItemOnBlock(
            class_7871<class_2248> blockLookup,
            class_7871<net.minecraft.class_1792> itemLookup,
            class_2248 block,
            class_2073.class_2074 item) {
        class_2090.class_2091 location = class_2090.class_2091.method_22484()
                .method_27989(net.minecraft.class_4550.class_4710.method_23880()
                        .method_27962(blockLookup, block));
        return class_4711.class_4712.method_27981(location, item);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  World / Dimensions
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player travels to the given dimension. */
    public static class_175<class_1999.class_2001> enterDimension(
            class_5321<class_1937> dimension) {
        return class_1999.class_2001.method_35068(null, dimension);
    }

    /** Fires when the player travels from {@code from} to {@code to}. */
    public static class_175<class_1999.class_2001> changeDimension(
            class_5321<class_1937> from, class_5321<class_1937> to) {
        return class_1999.class_2001.method_35068(from, to);
    }

    /** Fires on any dimension change. */
    public static class_175<class_1999.class_2001> anyDimensionChange() {
        return class_1999.class_2001.method_35068(null, null);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Player state
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires every tick. Good for root/hidden advancements. */
    public static class_175<class_2135.class_2137> tick() {
        return class_2135.class_2137.method_49195();
    }

    /** Never fires – use for manually granted advancements. */
    public static class_175<class_2062.class_2063> never() {
        return class_174.field_1184.method_53699(new class_2062.class_2063());
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Animals
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player tames the given entity type. */
    public static class_175<class_2131.class_2133> tameAnimal(
            class_1299<?> type) {
        return class_2131.class_2133.method_16114(
                class_2048.class_2049.method_8916()
                        .method_8917(new class_2050(class_6885.method_40246(type.method_40124())))
        );
    }

    /** Fires when the player breeds two animals of the given types. */
    public static class_175<class_196.class_198> breedAnimals(
            class_1299<?> parent, class_1299<?> partner) {
        return class_196.class_198.method_29918(
                Optional.of(
                        class_2048.class_2049.method_8916()
                                .method_8917(new class_2050(class_6885.method_40246(parent.method_40124())))
                                .method_8920()
                ),
                Optional.of(
                        class_2048.class_2049.method_8916()
                                .method_8917(new class_2050(class_6885.method_40246(partner.method_40124())))
                                .method_8920()
                ),
                Optional.empty()
        );
    }

    /** Fires when the player breeds any two animals. */
    public static class_175<class_196.class_198> breedAnyAnimals() {
        return class_196.class_198.method_29918(
                Optional.empty(), Optional.empty(), Optional.empty()
        );
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Crafting / Trading
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player crafts the recipe with the given key. */
    public static class_175<class_8508.class_8509> craftRecipe(
            class_5321<class_1860<?>> recipeKey) {
        return class_8508.class_8509.method_51352(recipeKey);
    }

    /** Fires when the player completes a trade with any villager. */
    public static class_175<class_2140.class_2142> tradeWithVillager() {
        return class_2140.class_2142.method_9153();
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Misc vanilla
    // ═════════════════════════════════════════════════════════════════════════

    /** Fires when the player sleeps in a bed. */
    public static class_175<class_2135.class_2137> sleepInBed() {
        return class_2135.class_2137.method_43138();
    }

    /** Fires when the player constructs a beacon at the given power level. */
    public static class_175<class_2006.class_2008> buildBeacon(
            int level) {
        return class_2006.class_2008.method_8818(class_2096.class_2100.method_9053(level));
    }

    /** Fires when the player shoots a crossbow with the given item. */
    public static class_175<class_2123.class_2125> shootCrossbow(
            class_7871<net.minecraft.class_1792> itemRegistry,
            class_1935 item) {
        return class_2123.class_2125.method_9120(itemRegistry, item);
    }

    /**
     * Custom / modded criterion by its registered id.
     *
     * [⚠️] You must pass a valid conditions instance.
     */
    @SuppressWarnings("unchecked")
    public static <T extends class_184> class_175<T> custom(
            String criterionId, T conditions) {
        var criterion = (class_179<T>) class_7923.field_47496.method_63535(class_2960.method_60654(criterionId));
        if (criterion == null) {
            throw new IllegalArgumentException("Unknown criterion: " + criterionId);
        }
        return criterion.method_53699(conditions);
    }
}