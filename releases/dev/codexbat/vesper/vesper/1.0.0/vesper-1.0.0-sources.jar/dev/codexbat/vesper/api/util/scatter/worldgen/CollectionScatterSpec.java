package dev.codexbat.vesper.api.util.scatter.worldgen;

import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

/**
 * For custom collection blocks like pebbles, shells, shards, etc.
 * This is the "multiple instances of a smaller block" type you described.
 */
public record CollectionScatterSpec(
        class_2248 collectionBlock,
        class_2680 scatteredBlock,
        int radius,
        int maxCount,
        float density,
        Predicate<class_2680> canReplace,
        Predicate<class_2680> canPlaceOn
) implements ScatterWorldgenSpec {
}