package dev.codexbat.vesper.client.glint.internal.render;

import dev.codexbat.vesper.api.glint.ParticleConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_11944;
import net.minecraft.class_1297;
import net.minecraft.class_3940;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9848;
import org.joml.Quaternionf;

/**
 * World-space glint particle that physically tracks a Minecraft entity.
 *
 * Instead of an absolute world position, this particle stores an entity
 * reference and a fixed offset from that entity's feet. Each tick,
 * this.x/y/z is updated to entity.getX/Y/Z() + offset. The standard
 * BillboardParticle lerp between lastX/Y/Z and x/y/z then interpolates
 * entity movement identically to how the entity model renderer does it,
 * so camera-relative position is stable regardless of camera movement.
 *
 * Without this, particles spawn at tick-time world positions while the
 * camera interpolates smoothly between ticks, causing the particle cloud
 * to drift relative to the item every render frame.
 */
@Environment(EnvType.CLIENT)
public final class WorldGlintParticle extends class_3940 {

    private static final float WORLD_PIXEL = 0.016f;

    private final class_1297 trackedEntity;
    /** Offset from entity feet to particle spawn, in world-axis space. Baked at spawn. */
    private final double offsetX, offsetY, offsetZ;

    private final ParticleConfig.Shape shape;
    private final boolean fadeOut;
    private final float quadHalfSize;
    private final float baseAlpha;

    WorldGlintParticle(class_638 world,
                       class_1297 trackedEntity,
                       double offsetX, double offsetY, double offsetZ,
                       class_1058 sprite,
                       ParticleConfig config,
                       float alphaMultiplier) {
        super(world,
                trackedEntity.method_23317() + offsetX,
                trackedEntity.method_23318() + offsetY,
                trackedEntity.method_23321() + offsetZ,
                sprite);

        this.trackedEntity = trackedEntity;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.offsetZ = offsetZ;

        this.shape   = config.getShape();
        this.fadeOut = config.isFadeOut();

        // Config lifetime is screen-space frames (60 fps). Convert to game ticks (20 tps).
        this.field_3847 = Math.max(1, Math.round(config.getLifetime() * WorldGlintParticleManager.LIFETIME_SCALE));
        this.field_3866    = 0;

        float rawSize = config.getSizeMin()
                + this.field_3840.method_43057() * (config.getSizeMax() - config.getSizeMin());
        this.quadHalfSize = rawSize * WORLD_PIXEL * 0.5f;
        this.field_17867 = 1.0f;

        int argb = config.getColor();
        this.baseAlpha = ((argb >> 24) & 0xFF) / 255.0f * alphaMultiplier;
        this.field_62633       = ((argb >> 16) & 0xFF) / 255.0f;
        this.field_62634     = ((argb >>  8) & 0xFF) / 255.0f;
        this.field_62635      = ( argb        & 0xFF) / 255.0f;
        this.field_62636     = this.baseAlpha;

        this.field_3862 = false;
        this.field_3852 = 0.0;
        this.field_3869 = 0.0;
        this.field_3850 = 0.0;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }

    /**
     * Save last position, then advance to entity's current tick position.
     *
     * lastX = entity.getX() at end of the PREVIOUS tick
     * this.x = entity.getX() at end of THIS tick
     *
     * lerp(tickProgress, lastX, x) in render() then equals
     * lerp(tickProgress, entity.lastX, entity.getX()) + offsetX,
     * which is exactly how the entity model interpolates its own position.
     * Camera.getCameraPos() uses the same interpolation, so they cancel:
     * the particle appears locked to the item regardless of camera motion.
     */
    @Override
    public void method_3070() {
        if (this.trackedEntity.method_31481()) {
            this.method_3085();
            return;
        }

        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        this.field_3874 = this.trackedEntity.method_23317() + this.offsetX;
        this.field_3854 = this.trackedEntity.method_23318() + this.offsetY;
        this.field_3871 = this.trackedEntity.method_23321() + this.offsetZ;

        this.field_62636 = this.fadeOut
                ? this.baseAlpha * (1.0f - (float) this.field_3866 / this.field_3847)
                : this.baseAlpha;
    }

    @Override
    protected void method_60373(class_11944 submittable,
                          class_4184 camera, Quaternionf rotation, float tickProgress) {
        if (this.field_62636 <= 0.0f || this.trackedEntity.method_31481()) return;

        float ix = (float)(lerp(tickProgress, this.field_3858, this.field_3874) - camera.method_71156().field_1352);
        float iy = (float)(lerp(tickProgress, this.field_3838, this.field_3854) - camera.method_71156().field_1351);
        float iz = (float)(lerp(tickProgress, this.field_3856, this.field_3871) - camera.method_71156().field_1350);

        switch (this.shape) {
            case SQUARE  -> drawQuad(submittable, rotation, ix, iy, iz, quadHalfSize);
            case DIAMOND -> drawDiamond(submittable, rotation, ix, iy, iz);
            case CROSS   -> drawCross(submittable, rotation, ix, iy, iz);
            case CIRCLE  -> drawCircle(submittable, rotation, ix, iy, iz);
        }
    }

    private void drawQuad(class_11944 sub, Quaternionf rot,
                          float cx, float cy, float cz, float half) {
        sub.method_74323(
                method_74255(),
                cx, cy, cz,
                rot.x, rot.y, rot.z, rot.w,
                half * 2.0f,
                method_18133(), method_18134(),
                method_18135(), method_18136(),
                class_9848.method_61318(this.field_62636, this.field_62633, this.field_62634, this.field_62635),
                15728880 // full-bright
        );
    }

    private void drawDiamond(class_11944 sub, Quaternionf rot, float cx, float cy, float cz) {
        float h = quadHalfSize, o = h * 1.2f;
        drawQuad(sub, rot, cx,     cy,     cz, h);
        drawQuad(sub, rot, cx + o, cy,     cz, h * 0.6f);
        drawQuad(sub, rot, cx - o, cy,     cz, h * 0.6f);
        drawQuad(sub, rot, cx,     cy + o, cz, h * 0.6f);
        drawQuad(sub, rot, cx,     cy - o, cz, h * 0.6f);
    }

    private void drawCross(class_11944 sub, Quaternionf rot, float cx, float cy, float cz) {
        float o = quadHalfSize * 2.0f;
        drawQuad(sub, rot, cx,     cy,     cz, quadHalfSize);
        drawQuad(sub, rot, cx + o, cy,     cz, quadHalfSize);
        drawQuad(sub, rot, cx - o, cy,     cz, quadHalfSize);
        drawQuad(sub, rot, cx,     cy + o, cz, quadHalfSize);
        drawQuad(sub, rot, cx,     cy - o, cz, quadHalfSize);
    }

    private void drawCircle(class_11944 sub, Quaternionf rot, float cx, float cy, float cz) {
        float o = quadHalfSize * 1.8f;
        drawQuad(sub, rot, cx,     cy,     cz, quadHalfSize);
        drawQuad(sub, rot, cx + o, cy,     cz, quadHalfSize * 0.7f);
        drawQuad(sub, rot, cx - o, cy,     cz, quadHalfSize * 0.7f);
        drawQuad(sub, rot, cx,     cy + o, cz, quadHalfSize * 0.7f);
        drawQuad(sub, rot, cx,     cy - o, cz, quadHalfSize * 0.7f);
    }

    private static double lerp(float delta, double prev, double curr) {
        return prev + delta * (curr - prev);
    }
}