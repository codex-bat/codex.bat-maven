package dev.codexbat.vesper.plush;

import dev.codexbat.vesper.plush.block.PlushyBlock;
import dev.codexbat.vesper.plush.block.entity.PlushyBlockEntity;
import dev.codexbat.vesper.plush.entity.PlushyEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5431;

/** Placed on a surface to spawn a PlushyEntity. Item model stays as the converted Blockbench JSON. */
public class PlushyItem extends class_1792 {

    private final PlushyDefinition definition;

    public PlushyItem(PlushyDefinition definition, class_1793 settings) {
        super(settings);
        this.definition = definition;
    }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        class_1937 world = ctx.method_8045();
        class_2338 pos = ctx.method_8037().method_10093(ctx.method_8038());

        // Reject non-solid surfaces (tall grass, flowers, panes, etc.) — same check vanilla uses
        if (!world.method_8320(ctx.method_8037())
                .method_30368(world, ctx.method_8037(), ctx.method_8038(), class_5431.field_25822)) {
            return class_1269.field_5811;
        }

        // Target spot must be empty — PASS keeps the arm from swinging
        if (!world.method_8320(pos).method_26215()) {
            return class_1269.field_5811;
        }

        // Spot is free: client confirms the swing, server does the work
        if (world.method_8608()) {
            return class_1269.field_5812;
        }

        // Face toward the player, same convention as a furnace
        class_2350 facing = ctx.method_8042().method_10153();
        class_2680 state = PlushyRegistry.PLUSHY_BLOCK.method_9564()
                .method_11657(PlushyBlock.FACING, facing);

        if (!world.method_8652(pos, state, class_2248.field_31036)) {
            return class_1269.field_5814;
        }

        if (world.method_8321(pos) instanceof PlushyBlockEntity be) {
            be.setDefinitionId(definition.getId());
        }

        world.method_8396(
                null,
                pos,
                class_3417.field_15226,
                class_3419.field_15245,
                1.0f,
                0.8f + world.field_9229.method_43057() * 0.4f
        );

        class_1657 player = ctx.method_8036();
        if (player != null && !player.method_68878()) {
            ctx.method_8041().method_7934(1);
        }

        return class_1269.field_21466;
    }

    public PlushyDefinition getDefinition() { return definition; }
}