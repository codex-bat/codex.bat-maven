package dev.codexbat.vesper.plush.block;

import com.mojang.serialization.MapCodec;
import dev.codexbat.vesper.plush.PlushyRegistry;
import dev.codexbat.vesper.plush.block.entity.PlushyBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class PlushyBlock extends class_2237 {

    public static final MapCodec<PlushyBlock> CODEC = method_54094(PlushyBlock::new);
    public static final class_2754<class_2350> FACING = class_2741.field_12481;

    private static final class_265 SHAPE_NS =
            class_2248.method_9541(4.5, 0, 5.5, 11.5, 12.5, 10.5);
    private static final class_265 SHAPE_EW =
            class_2248.method_9541(5.5, 0, 4.5, 10.5, 12.5, 11.5);

    private static class_265 shape(class_2680 state) {
        class_2350 f = state.method_11654(FACING);
        return (f == class_2350.field_11034 || f == class_2350.field_11039) ? SHAPE_EW : SHAPE_NS;
    }

    public PlushyBlock(class_2251 settings) {
        super(settings);
        // Explicit default so the block always has a well-defined facing on first placement.
        method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    // Placement

    /** Prevents placement on non-solid surfaces (glass panes, fences, slabs, ...). */
    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 below = pos.method_10074();
        return world.method_8320(below).method_30368(world, below, class_2350.field_11036, class_5431.field_25822);
    }

    /**
     * Breaks and drops when the supporting block is removed.
     * A loot table at data/modid/loot_tables/blocks/block.json is required
     * for the item to actually be dropped on the ground.
     */
    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        return method_9558(state, world, pos)
                ? super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random)
                : class_2246.field_10124.method_9564();
    }

    // Block entity

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PlushyBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 world, class_2680 state, class_2591<T> type
    ) {
        return method_31618(
                type,
                PlushyRegistry.PLUSHY_BLOCK_ENTITY,
                (w, p, s, be) -> be.tick()
        );
    }

    // Interaction

    @Override
    protected class_1269 method_55765(
            class_1799 stack,
            class_2680 state,
            class_1937 world,
            class_2338 pos,
            class_1657 player,
            class_1268 hand,
            class_3965 hit
    ) {
        if (world.method_8321(pos) instanceof PlushyBlockEntity plushy) {
            // squish() returns false while an entity is standing on top - skip sound then.
            if (plushy.squish()) {
                world.method_8396(
                        null, pos,
                        class_3417.field_14628, class_3419.field_15245,
                        0.8f, 0.9f + world.field_9229.method_43057() * 0.2f
                );
            }
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity) {
        super.method_9591(world, pos, state, entity);
        if (world.method_8608()) return;
        if (world.method_8321(pos) instanceof PlushyBlockEntity plushy) {
            plushy.squish(); // no-op while held; return value intentionally ignored here
        }
    }

    // Creative pick

    /** Middle-click in creative returns this block's item. */
    @Override
    protected class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
        return new class_1799(this.method_8389());
    }

    // Rendering

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }

    // Shapes

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return shape(state);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return shape(state);
    }

    @Override
    public class_265 method_9584(class_2680 state, class_1922 world, class_2338 pos) {
        return shape(state);
    }

    @Override
    protected class_265 method_9571(class_2680 state) {
        return shape(state);
    }
}