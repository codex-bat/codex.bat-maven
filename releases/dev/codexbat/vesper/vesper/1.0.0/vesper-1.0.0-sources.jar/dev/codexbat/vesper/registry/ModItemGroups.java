package dev.codexbat.vesper.registry;

import dev.codexbat.vesper.Vesper;
import dev.codexbat.vesper.plush.PlushyDefinition;
import dev.codexbat.vesper.plush.PlushyRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class ModItemGroups {
    private ModItemGroups() {}

    public static void initialize() {
        class_1792 plushyIcon = PlushyRegistry.getItem(Vesper.id("codex_plush"));

        class_1761 VESPER_TAB = FabricItemGroup.builder()
                .method_47320(() -> new class_1799(plushyIcon))
                .method_47321(class_2561.method_43471("itemGroup.vesper.plushies"))
                .method_47317((context, entries) -> {
                    for (PlushyDefinition def : PlushyRegistry.getAllDefinitions()) {
                        class_1792 item = PlushyRegistry.getItem(def.getId());
                        if (item != null) entries.method_45421(item);
                    }
                })
                .method_47324();

        class_2378.method_10230(class_7923.field_44687, Vesper.id("vesper_tab"), VESPER_TAB);
    }
}