package dev.codexbat.vesper.api.util.scatter;

import dev.codexbat.vesper.api.block.stackable.StackDecayConfig;
import dev.codexbat.vesper.api.block.stackable.StackableBlock;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public final class ScatterLogic {
    private ScatterLogic() {}

    public static void pause(class_2586 be) {
        if (be instanceof StackableScatterState state) {
            state.vesper$setScatterPaused(true);
            be.method_5431();
        }
    }

    public static void resume(class_2586 be) {
        if (be instanceof StackableScatterState state) {
            state.vesper$setScatterPaused(false);
            be.method_5431();
        }
    }

    public static boolean tick(class_1937 world,
                               class_2338 pos,
                               class_2680 state,
                               StackableScatterState be,
                               StackableBlock stackable) {
        if (world == null || world.method_8608()) return false;
        if (be.vesper$isScatterPaused()) return false;

        if (be.vesper$getScatterCooldown() > 0) {
            be.vesper$setScatterCooldown(be.vesper$getScatterCooldown() - 1);
            return false;
        }

        StackDecayConfig config = stackable.vesper$getDecayConfig(state);
        int currentCount = stackable.vesper$getStackCount(state);

        if (config.isStable(currentCount)) {
            be.vesper$setFragile(false);
            return false;
        }

        if (!be.vesper$isFragile()) {
            if (!config.isFragile(currentCount)) return false;
            be.vesper$setFragile(true);
        }

        if (ThreadLocalRandom.current().nextFloat() > config.chancePerTick()) {
            return false;
        }

        int nextCount = Math.max(config.stableMin(), currentCount - 1);
        class_2680 nextState = stackable.vesper$withStackCount(state, nextCount);
        world.method_8652(pos, nextState, 3);

        scatterOne(world, pos, config.scatterRadius(), config.scatterAttempts(), config.scatteredBlock());

        if (config.isStable(nextCount)) {
            be.vesper$setFragile(false);
        }

        be.vesper$setScatterCooldown(1);
        be.vesper$setScatterPaused(false);
        be.vesper$setScatterPaused(be.vesper$isScatterPaused());
        if (be instanceof class_2586 blockEntity) {
            blockEntity.method_5431();
        }
        return true;
    }

    private static boolean scatterOne(class_1937 world,
                                      class_2338 origin,
                                      int radius,
                                      int attempts,
                                      class_2680 scatteredBlock) {
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < attempts; i++) {
            int dx = random.nextInt(-radius, radius + 1);
            int dy = random.nextInt(-1, 2);
            int dz = random.nextInt(-radius, radius + 1);

            class_2338 target = origin.method_10069(dx, dy, dz);
            if (world.method_8320(target).method_26215()) {
                world.method_8652(target, scatteredBlock, 3);
                return true;
            }
        }

        for (class_2350 direction : class_2350.values()) {
            class_2338 target = origin.method_10093(direction);
            if (world.method_8320(target).method_26215()) {
                world.method_8652(target, scatteredBlock, 3);
                return true;
            }
        }

        return false;
    }
}