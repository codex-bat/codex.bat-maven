package dev.codexbat.vesper.api.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancement.*;
import net.minecraft.class_12079;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1799;
import net.minecraft.class_184;
import net.minecraft.class_185;
import net.minecraft.class_1860;
import net.minecraft.class_189;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8779;
import net.minecraft.class_8782;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Abstract base class for advancement providers. Extend this and implement
 * {@link #generate(Consumer, class_7225.class_7874)}.
 *
 * <p>Features a fluent {@link AdvancementBuilder} accessible via
 * {@link #advancement(class_2960)}, and a helper
 * for referencing vanilla advancements as parents.
 *
 * <p><b>Usage:</b>
 * <pre>
 * public class MyAdvancementProvider extends VesperAdvancementProvider {
 *     public MyAdvancementProvider(FabricDataOutput out, CompletableFuture&lt;...&gt; reg) {
 *         super(out, reg);
 *     }
 *
 *     {@literal @}Override
 *     protected void generate(Consumer&lt;AdvancementEntry&gt; exporter, RegistryWrapper.WrapperLookup lookup) {
 *         AdvancementEntry root = advancement(id("root"))
 *             .title("My Mod Advancements")
 *             .description("Where it all begins")
 *             .icon(Items.DIAMOND)
 *             .background(Identifier.of("textures/block/stone.png"))
 *             .criterion("tick", VesperCriteria.tick())
 *             .secret()
 *             .build(exporter);
 *
 *         advancement(id("get_diamond"))
 *             .parent(root)
 *             .title("Shiny!")
 *             .description("Pick up a diamond")
 *             .icon(Items.DIAMOND)
 *             .task()
 *             .criterion("diamond", VesperCriteria.obtainItem(Items.DIAMOND))
 *             .build(exporter);
 *     }
 * }
 * </pre>
 */
public abstract class VesperAdvancementProvider extends FabricAdvancementProvider {

    protected VesperAdvancementProvider(FabricDataOutput output,
                                        CompletableFuture<class_7225.class_7874> lookup) {
        super(output, lookup);
    }

    @Override
    public final void generateAdvancement(class_7225.class_7874 lookup,
                                          Consumer<class_8779> exporter) {
        generate(exporter, lookup);
    }

    /**
     * Implement this to declare your advancements.
     *
     * @param exporter pass to {@link AdvancementBuilder#build} to write each advancement
     * @param lookup   registry access; use {@link #vanilla(String, class_7225.class_7874)}
     *                 to reference vanilla advancements as parents
     */
    protected abstract void generate(Consumer<class_8779> exporter,
                                     class_7225.class_7874 lookup);

    // ── Helpers available inside generate() ──────────────────────────────────

    /** Start building an advancement with the given id. */
    protected static AdvancementBuilder advancement(class_2960 id) {
        return new AdvancementBuilder(id);
    }

    /**
     * Look up a vanilla advancement entry so you can use it as a parent.
     *
     * <pre>
     * .parent(vanilla("story/root", lookup))
     * .parent(vanilla("nether/root", lookup))
     * </pre>
     */
    protected static class_6880.class_6883<class_161> vanilla(String path, class_7225.class_7874 lookup) {
        return lookup
                .method_46762(class_7924.field_52177)
                .method_46747(class_5321.method_29179(class_7924.field_52177, class_2960.method_60655("minecraft", path)));
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Fluent AdvancementBuilder
    // ═════════════════════════════════════════════════════════════════════════

    public static final class AdvancementBuilder {

        private final class_2960 id;
        private final class_161.class_162 vanilla = class_161.class_162.method_707();

        // Display fields
        private class_2561 title;
        private class_2561 description;
        private class_1799 icon;
        private class_2960 background;       // only relevant for root advancements
        private class_189 frame = class_189.field_1254;
        private boolean showToast = true;
        private boolean announceToChat = true;
        private boolean hidden = false;

        private AdvancementBuilder(class_2960 id) {
            this.id = id;
        }

        // ── Parent ─────────────────────────────────────────────────────────

        /** Chain off a previously built advancement. */
        public AdvancementBuilder parent(class_8779 parent) {
            vanilla.method_701(parent);
            return this;
        }

        /**
         * Reference a parent by its full string identifier, e.g.
         * {@code "minecraft:story/root"} — useful if you don't have the
         * AdvancementEntry object at hand.
         */
        @SuppressWarnings("deprecation")
        public AdvancementBuilder parent(class_2960 parentId) {
            vanilla.method_708(parentId);
            return this;
        }

        // ── Display ────────────────────────────────────────────────────────

        public AdvancementBuilder title(class_2561 text) {
            this.title = text;
            return this;
        }

        /** Uses a translation key (preferred for localisable mods). */
        public AdvancementBuilder title(String key) {
            return title(class_2561.method_43471(key));
        }

        /** Literal string title — handy for quick prototyping. */
        public AdvancementBuilder titleLiteral(String literal) {
            return title(class_2561.method_43470(literal));
        }

        public AdvancementBuilder description(class_2561 text) {
            this.description = text;
            return this;
        }

        public AdvancementBuilder description(String key) {
            return description(class_2561.method_43471(key));
        }

        public AdvancementBuilder descriptionLiteral(String literal) {
            return description(class_2561.method_43470(literal));
        }

        public AdvancementBuilder icon(class_1935 item) {
            this.icon = new class_1799(item);
            return this;
        }

        public AdvancementBuilder icon(class_1799 stack) {
            this.icon = stack.method_7972();
            return this;
        }

        /**
         * Background texture. Only has visible effect on root advancements
         * (i.e. advancements with no parent).
         */
        public AdvancementBuilder background(class_2960 textureId) {
            this.background = textureId;
            return this;
        }

        // ── Frame / shape ──────────────────────────────────────────────────

        /** Plain square frame (default). */
        public AdvancementBuilder task() {
            this.frame = class_189.field_1254;
            return this;
        }

        /** Oval frame — for mid-tier goals. */
        public AdvancementBuilder goal() {
            this.frame = class_189.field_1249;
            return this;
        }

        /** Star-shaped frame, purple tint, loud fanfare. */
        public AdvancementBuilder challenge() {
            this.frame = class_189.field_1250;
            return this;
        }

        public AdvancementBuilder frame(class_189 frame) {
            this.frame = frame;
            return this;
        }

        // ── Visibility ─────────────────────────────────────────────────────

        /** Hide from the advancement screen until earned. */
        public AdvancementBuilder hidden() {
            this.hidden = true;
            return this;
        }

        /** Suppress the on-screen toast notification. */
        public AdvancementBuilder noToast() {
            this.showToast = false;
            return this;
        }

        /** Suppress the chat message on completion. */
        public AdvancementBuilder silent() {
            this.announceToChat = false;
            return this;
        }

        /** hidden + noToast + silent — for internal/trigger-only advancements. */
        public AdvancementBuilder secret() {
            return hidden().noToast().silent();
        }

        // ── Criteria ───────────────────────────────────────────────────────

        /**
         * Add a named criterion. Use {@link VesperCriteria} for convenient
         * factories covering every vanilla criterion type.
         */
        public <T extends class_184> AdvancementBuilder criterion(
                String name, class_175<T> criterion) {
            vanilla.method_705(name, criterion);
            return this;
        }

        // ── Requirements (AND / OR grouping) ──────────────────────────────

        // To use OR groups you must build the AdvancementRequirements yourself
        // and set it via the dedicated method. Example:
        //
        // AdvancementRequirements req = AdvancementRequirements.anyOf(Set.of("sword", "axe"));
        // builder.requirements(req);
        //
        // The vanilla builder does not expose a method to add individual OR groups,
        // so this builder does not include a requireAny shortcut.

        public AdvancementBuilder requirements(class_8782 requirements) {
            vanilla.method_34884(requirements);
            return this;
        }

        // ── Rewards ────────────────────────────────────────────────────────

        public AdvancementBuilder rewardXp(int amount) {
            vanilla.method_703(class_170.class_171.method_750(amount));
            return this;
        }

        /**
         * Add a recipe reward.
         * @param recipeId e.g. {@code Identifier.of("minecraft", "some_recipe")}
         */
        public AdvancementBuilder rewardRecipe(class_2960 recipeId) {
            class_5321<class_1860<?>> recipeKey = class_5321.method_29179(class_7924.field_52178, recipeId);
            vanilla.method_703(class_170.class_171.method_753(recipeKey));
            return this;
        }

        public AdvancementBuilder rewards(class_170 rewards) {
            vanilla.method_706(rewards);
            return this;
        }

        // ── Build ──────────────────────────────────────────────────────────

        /**
         * Applies the display, writes the advancement to {@code exporter},
         * and returns the resulting {@link class_8779} so it can be
         * passed to child advancements via {@link #parent(class_8779)}.
         */
        public class_8779 build(Consumer<class_8779> exporter) {
            if (title != null && description != null && icon != null) {
                vanilla.method_693(new class_185(
                        icon,
                        title,
                        description,
                        Optional.ofNullable(background)
                                .map(class_12079.class_10726::new),
                        frame,
                        showToast,
                        announceToChat,
                        hidden
                ));
            }
            return vanilla.method_694(exporter, id.toString());
        }
    }
}