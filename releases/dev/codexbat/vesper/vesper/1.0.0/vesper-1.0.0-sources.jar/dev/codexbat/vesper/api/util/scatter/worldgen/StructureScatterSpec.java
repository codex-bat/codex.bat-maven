package dev.codexbat.vesper.api.util.scatter.worldgen;

import net.minecraft.class_2960;

/**
 * For structure-style scattering where the final worldgen class decides
 * how the structure is actually placed.
 */
public record StructureScatterSpec(
        class_2960 structureId,
        int radius,
        float density,
        int attemptsPerChunk,
        int minY,
        int maxY
) implements ScatterWorldgenSpec {
}