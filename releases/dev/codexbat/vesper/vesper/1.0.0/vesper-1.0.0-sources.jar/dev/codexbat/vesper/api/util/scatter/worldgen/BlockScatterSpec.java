package dev.codexbat.vesper.api.util.scatter.worldgen;

import java.util.function.Predicate;
import net.minecraft.class_2680;

public record BlockScatterSpec(
        class_2680 state,
        int radius,
        float density,
        int attempts,
        Predicate<class_2680> canReplace,
        Predicate<class_2680> canPlaceOn
) implements ScatterWorldgenSpec {
}