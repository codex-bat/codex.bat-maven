package dev.codexbat.vesper.datagen.provider;

import dev.codexbat.vesper.Vesper;
import dev.codexbat.vesper.api.datagen.VesperBlockLootProvider;
import dev.codexbat.vesper.plush.PlushyRegistry;
import dev.codexbat.vesper.plush.loot.PlushyDropLootFunction;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_201;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;

public final class ModBlockLootProvider extends VesperBlockLootProvider {

    public ModBlockLootProvider(
            FabricDataOutput output,
            CompletableFuture<class_7225.class_7874> registries
    ) {
        super(output, registries);
    }

    @Override
    public void method_10379() {
        method_45988(
                PlushyRegistry.PLUSHY_BLOCK,
                class_52.method_324()
                        .method_336(class_55.method_347()
                                .method_352(class_44.method_32448(1))
                                .method_351(class_77.method_411(
                                        PlushyRegistry.getItem(Vesper.id("codex_plush"))
                                ).method_438(PlushyDropLootFunction.builder()))
                                .method_356(class_201.method_871()))
        );
    }
}