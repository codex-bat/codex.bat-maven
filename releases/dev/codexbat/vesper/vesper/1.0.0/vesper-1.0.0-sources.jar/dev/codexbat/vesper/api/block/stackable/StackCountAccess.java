package dev.codexbat.vesper.api.block.stackable;

import net.minecraft.class_2680;
import net.minecraft.class_2758;

public interface StackCountAccess {
    class_2758 vesper$getStackCountProperty();

    int vesper$getMinStackCount();

    int vesper$getMaxStackCount();

    default int vesper$getStackCount(class_2680 state) {
        return state.method_11654(vesper$getStackCountProperty());
    }

    default class_2680 vesper$withStackCount(class_2680 state, int count) {
        int clamped = Math.max(vesper$getMinStackCount(), Math.min(vesper$getMaxStackCount(), count));
        return state.method_11657(vesper$getStackCountProperty(), clamped);
    }
}