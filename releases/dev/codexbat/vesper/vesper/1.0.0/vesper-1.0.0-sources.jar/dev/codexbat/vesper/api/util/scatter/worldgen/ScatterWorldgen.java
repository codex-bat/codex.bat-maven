package dev.codexbat.vesper.api.util.scatter.worldgen;

import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

public final class ScatterWorldgen {
    private ScatterWorldgen() {}

    public static BlockScatterBuilder block(class_2680 state) {
        return new BlockScatterBuilder(state);
    }

    public static CollectionScatterBuilder collection(class_2248 collectionBlock, class_2680 scatteredBlock) {
        return new CollectionScatterBuilder(collectionBlock, scatteredBlock);
    }

    public static StructureScatterBuilder structure(class_2960 structureId) {
        return new StructureScatterBuilder(structureId);
    }

    public static final class BlockScatterBuilder {
        private final class_2680 state;
        private int radius = 4;
        private float density = 0.35f;
        private int attempts = 6;
        private Predicate<class_2680> canReplace = class_2680::method_26215;
        private Predicate<class_2680> canPlaceOn = s -> !s.method_26215();

        private BlockScatterBuilder(class_2680 state) {
            this.state = state;
        }

        public BlockScatterBuilder radius(int radius) { this.radius = radius; return this; }
        public BlockScatterBuilder density(float density) { this.density = density; return this; }
        public BlockScatterBuilder attempts(int attempts) { this.attempts = attempts; return this; }
        public BlockScatterBuilder canReplace(Predicate<class_2680> canReplace) { this.canReplace = canReplace; return this; }
        public BlockScatterBuilder canPlaceOn(Predicate<class_2680> canPlaceOn) { this.canPlaceOn = canPlaceOn; return this; }

        public BlockScatterSpec build() {
            return new BlockScatterSpec(state, radius, density, attempts, canReplace, canPlaceOn);
        }
    }

    public static final class CollectionScatterBuilder {
        private final class_2248 collectionBlock;
        private final class_2680 scatteredBlock;
        private int radius = 4;
        private int maxCount = 8;
        private float density = 0.35f;
        private Predicate<class_2680> canReplace = class_2680::method_26215;
        private Predicate<class_2680> canPlaceOn = s -> !s.method_26215();

        private CollectionScatterBuilder(class_2248 collectionBlock, class_2680 scatteredBlock) {
            this.collectionBlock = collectionBlock;
            this.scatteredBlock = scatteredBlock;
        }

        public CollectionScatterBuilder radius(int radius) { this.radius = radius; return this; }
        public CollectionScatterBuilder maxCount(int maxCount) { this.maxCount = maxCount; return this; }
        public CollectionScatterBuilder density(float density) { this.density = density; return this; }
        public CollectionScatterBuilder canReplace(Predicate<class_2680> canReplace) { this.canReplace = canReplace; return this; }
        public CollectionScatterBuilder canPlaceOn(Predicate<class_2680> canPlaceOn) { this.canPlaceOn = canPlaceOn; return this; }

        public CollectionScatterSpec build() {
            return new CollectionScatterSpec(collectionBlock, scatteredBlock, radius, maxCount, density, canReplace, canPlaceOn);
        }
    }

    public static final class StructureScatterBuilder {
        private final class_2960 structureId;
        private int radius = 16;
        private float density = 0.1f;
        private int attemptsPerChunk = 2;
        private int minY = -64;
        private int maxY = 320;

        private StructureScatterBuilder(class_2960 structureId) {
            this.structureId = structureId;
        }

        public StructureScatterBuilder radius(int radius) { this.radius = radius; return this; }
        public StructureScatterBuilder density(float density) { this.density = density; return this; }
        public StructureScatterBuilder attemptsPerChunk(int attemptsPerChunk) { this.attemptsPerChunk = attemptsPerChunk; return this; }
        public StructureScatterBuilder minY(int minY) { this.minY = minY; return this; }
        public StructureScatterBuilder maxY(int maxY) { this.maxY = maxY; return this; }

        public StructureScatterSpec build() {
            return new StructureScatterSpec(structureId, radius, density, attemptsPerChunk, minY, maxY);
        }
    }
}