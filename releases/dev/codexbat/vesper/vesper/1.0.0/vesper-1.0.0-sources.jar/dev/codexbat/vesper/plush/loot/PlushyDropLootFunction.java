package dev.codexbat.vesper.plush.loot;

import com.mojang.serialization.MapCodec;
import dev.codexbat.vesper.plush.PlushyRegistry;
import dev.codexbat.vesper.plush.block.entity.PlushyBlockEntity;
import java.util.Set;
import net.minecraft.class_117;
import net.minecraft.class_169;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import net.minecraft.class_5339;

public class PlushyDropLootFunction implements class_117 {

    public static final MapCodec<PlushyDropLootFunction> CODEC = MapCodec.unit(PlushyDropLootFunction::new);
    public static final class_5339<PlushyDropLootFunction> TYPE = new class_5339<>(CODEC);

    @Override
    public class_5339<PlushyDropLootFunction> method_29321() {
        return TYPE;
    }

    @Override
    public class_1799 apply(class_1799 stack, class_47 context) {
        class_2586 be = context.method_65013(class_181.field_1228);
        if (be instanceof PlushyBlockEntity plushy) {
            class_2960 definitionId = plushy.getDefinitionId();
            if (definitionId != null) {
                class_1799 newStack = new class_1799(PlushyRegistry.getItem(definitionId));
                newStack.method_7939(stack.method_7947());
                return newStack;
            }
        }
        return stack;
    }

    @Override
    public Set<class_169<?>> method_293() {
        return Set.of(class_181.field_1228);
    }

    public static class_117.class_118 builder() {
        return PlushyDropLootFunction::new;
    }
}