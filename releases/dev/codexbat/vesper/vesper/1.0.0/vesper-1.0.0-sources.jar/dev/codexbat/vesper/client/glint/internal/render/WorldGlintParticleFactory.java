package dev.codexbat.vesper.client.glint.internal.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * Registered with Fabric's ParticleFactoryRegistry solely to obtain and
 * cache the atlas sprite for the WORLD_GLINT particle type.
 *
 * createParticle() is never called at runtime. WorldGlintParticleManager
 * creates particles directly via ParticleManager.addParticle(Particle)
 * so that entity references can be passed to the constructor — something
 * the effect/factory pipeline cannot carry.
 */
@Environment(EnvType.CLIENT)
public final class WorldGlintParticleFactory
        implements class_707<WorldGlintParticleEffect> {

    public WorldGlintParticleFactory(class_4002 spriteProvider) {
        // Do NOT call getSprite() here — the atlas isn't stitched yet.
        // Store the provider; sprites are resolved at spawn time.
        WorldGlintParticleManager.SPRITE_PROVIDER = spriteProvider;
    }

    @Override
    public class_703 createParticle(WorldGlintParticleEffect effect,
                                   class_638 world,
                                   double x, double y, double z,
                                   double velX, double velY, double velZ,
                                   class_5819 random) {
        // Never called — particles are created directly in WorldGlintParticleManager.
        // Returning null is safe; ParticleManager silently drops null results.
        return null;
    }
}