package dev.codexbat.vesper.client.glint.internal;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class GlintTextures {
    public static final class_2960 WHITE_PIXEL = class_2960.method_60655("vesper", "textures/misc/white_pixel");

    private static volatile boolean initialized = false;

    /** Call this once from the render thread before using WHITE_PIXEL. */
    public static void ensureInitialized() {
        if (initialized) return;

        class_1011 image = new class_1011(class_1011.class_1012.field_4997, 1, 1, false);
        image.method_61941(0, 0, 0xFFFFFFFF);

        class_1043 texture = new class_1043(
                () -> "vesper_white_pixel",   // GPU debug label
                image
        );

        class_310.method_1551()
                .method_1531()
                .method_4616(WHITE_PIXEL, texture);

        initialized = true;
    }
}