package dev.codexbat.vesper.client.plush.render;

import dev.codexbat.vesper.plush.PlushyRegistry;
import dev.codexbat.vesper.plush.block.PlushyBlock;
import dev.codexbat.vesper.plush.block.entity.PlushyBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class PlushyBlockEntityRenderer
        implements class_827<PlushyBlockEntity, PlushyBlockEntityRenderer.PlushyRenderState> {

    private final class_1087 model;

    public PlushyBlockEntityRenderer(class_5614.class_5615 ctx) {
        class_2680 state = PlushyRegistry.PLUSHY_BLOCK.method_9564();
        this.model = ctx.comp_4535().method_3351().method_3335(state);
    }

    public static final class PlushyRenderState extends class_11954 {
        public float squish;
        public class_2350 facing = class_2350.field_11043;
    }

    @Override
    public PlushyRenderState method_74335() {
        return new PlushyRenderState();
    }

    @Override
    public void updateRenderState(
            PlushyBlockEntity blockEntity,
            PlushyRenderState state,
            float tickProgress,
            class_243 cameraPos,
            class_11683.@Nullable class_11792 crumblingOverlay
    ) {
        class_827.super.method_74331(blockEntity, state, tickProgress, cameraPos, crumblingOverlay);
        state.squish = blockEntity.getSquish(tickProgress);
        state.facing = blockEntity.method_11010().method_11654(PlushyBlock.FACING);
    }

    @Override
    public void render(
            PlushyRenderState state,
            class_4587 matrices,
            class_11659 queue,
            class_12075 cameraState
    ) {
        float baseScale = 0.943f;
        float squishScaleY = 1.0f - (state.squish * 0.08f);

        float yaw = switch (state.facing) {
            case field_11039 -> 90.0f;
            case field_11035 -> 180.0f;
            case field_11034 -> 270.0f;
            default -> 0.0f;
        };

        matrices.method_22903();
        matrices.method_22904(0.5, 0.0, 0.5);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw));
        matrices.method_22905(baseScale, baseScale * squishScaleY, baseScale);
        matrices.method_22904(-0.5, 0.0, -0.5);

        queue.method_73484(
                matrices,
                class_12249.method_75972(),
                this.model,
                1.0f, 1.0f, 1.0f,
                state.field_62676,
                class_4608.field_21444,
                0
        );

        matrices.method_22909();
    }
}