package dev.codexbat.vesper.plush.block.entity;

import dev.codexbat.vesper.plush.PlushyRegistry;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import org.jspecify.annotations.Nullable;

public class PlushyBlockEntity extends class_2586 {

    public static final String DEFINITION_KEY = "PlushyDefinition";
    private class_2960 definitionId;   // null until set

    private static final int SQUISH_DURATION = 6;

    private int     squishTicks = 0;
    private boolean entityOnTop = false;  // server-side only, not synced

    public PlushyBlockEntity(class_2338 pos, class_2680 state) {
        super(PlushyRegistry.PLUSHY_BLOCK_ENTITY, pos, state);
    }

    /** Called from PlushyItem when the block is placed */
    public void setDefinitionId(class_2960 id) {
        this.definitionId = id;
        method_5431();
        notifyListeners();
    }

    public class_2960 getDefinitionId() {
        return definitionId;
    }

    // Public API

    /**
     * Triggers the short tap-squish animation.
     *
     * @return {@code true} if the squish was applied;
     *         {@code false} if blocked because an entity is currently standing on top.
     */
    public boolean squish() {
        if (entityOnTop) return false;
        squishTicks = SQUISH_DURATION;
        method_5431();
        notifyListeners();
        return true;
    }

    /**
     * Interpolated squish value in [0, 1].
     * Fades from 1 to 0 over SQUISH_DURATION ticks after each squish trigger.
     */
    public float getSquish(float tickDelta) {
        float t = Math.max(0.0f, squishTicks - tickDelta);
        return t / (float) SQUISH_DURATION;
    }

    // Tick

    public void tick() {
        if (field_11863 == null) return;

        if (!field_11863.method_8608()) {
            boolean onTop = checkEntityOnTop();
            if (entityOnTop && !onTop) {
                // Entity just stepped off - trigger the spring-back animation.
                squishTicks = SQUISH_DURATION;
                method_5431();
                notifyListeners();
            }
            entityOnTop = onTop;
        }

        if (squishTicks > 0) {
            squishTicks--;
        }
    }

    // Internals

    /**
     * Returns true when a living entity's feet sit within the narrow tolerance
     * band at the top surface of the collision shape (Y + 12.5/16 ~= Y + 0.781).
     *
     * <p>Entities standing beside the block are at Y + 0, so their
     * foot Y differs from topY by ~0.78 - well outside the 0.1 tolerance.
     */
    private boolean checkEntityOnTop() {
        if (field_11863 == null || field_11863.method_8608()) return false;

        double topY   = field_11867.method_10264() + 12.5 / 16.0;
        class_238    region = new class_238(
                field_11867.method_10263(),       topY - 0.05, field_11867.method_10260(),
                field_11867.method_10263() + 1.0, topY + 2.0,  field_11867.method_10260() + 1.0
        );

        return !field_11863.method_8390(
                class_1309.class,
                region,
                entity -> Math.abs(entity.method_23318() - topY) <= 0.1
        ).isEmpty();
    }

    private void notifyListeners() {
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    // Serialisation

    @Override
    protected void method_11014(class_11368 view) {
        squishTicks = view.method_71424("SquishTicks", 0);
        String def = view.method_71428(DEFINITION_KEY, null);
        this.definitionId = def == null ? null : class_2960.method_60654(def);
    }

    @Override
    protected void method_11007(class_11372 view) {
        view.method_71465("SquishTicks", squishTicks);
        if (definitionId != null) {
            view.method_71469(DEFINITION_KEY, definitionId.toString());
        }
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 nbt = method_38244(registries);
        if (definitionId != null) {
            nbt.method_10582(DEFINITION_KEY, definitionId.toString());
        }
        return nbt;
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}