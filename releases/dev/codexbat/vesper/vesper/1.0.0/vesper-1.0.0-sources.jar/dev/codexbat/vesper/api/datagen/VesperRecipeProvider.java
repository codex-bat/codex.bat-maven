package dev.codexbat.vesper.api.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public abstract class VesperRecipeProvider extends class_2446.class_10114 {

    protected VesperRecipeProvider(FabricDataOutput output,
                                   CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected final class_2446 method_62766(class_7225.class_7874 registries,
                                                       class_8790 exporter) {
        return new class_2446(registries, exporter) {
            @Override
            public void method_10419() {
                buildRecipes(new VesperRecipes(this, field_53721, field_48981));
            }
        };
    }

    protected abstract void buildRecipes(VesperRecipes recipes);
}