package dev.codexbat.vesper.plush.entity;

import com.mojang.serialization.Codec;
import dev.codexbat.vesper.plush.PlushyDefinition;
import dev.codexbat.vesper.plush.PlushyRegistry;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Non-living entity — no AI, no health, no attributes.
 *
 * Right-click  → squish scale + sound.
 * Any hit      → drop item + discard (creative: silent delete).
 * Collision    → AABB from EntityType.dimensions() in PlushyRegistry.
 */
public class PlushyEntity extends class_1297 {

    // ── Tracked data ──────────────────────────────────────────────────────────

    private static final class_2940<String> DEFINITION_ID =
            class_2945.method_12791(PlushyEntity.class, class_2943.field_13326);

    /**
     * Counts down {@link #SQUISH_DURATION} → 0 after each right-click.
     * Server writes it; both sides read it. Renderer normalises to 0–1.
     */
    private static final class_2940<Integer> SQUISH_TICK =
            class_2945.method_12791(PlushyEntity.class, class_2943.field_13327);

    /** Duration of the squish animation in ticks. Public so the renderer can normalise. */
    public static final int SQUISH_DURATION = 10;

    // ── Client-side animation fields ──────────────────────────────────────────

    /** 0 = T-pose, 1 = arms fully drooped. */
    public float armProgress     = 0f;
    public float prevArmProgress = 0f;

    /** Incremented each tick; drives the idle bob sine. */
    public float bobPhase     = 0f;
    public float prevBobPhase = 0f;

    // ── Construction ─────────────────────────────────────────────────────────

    public PlushyEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        this.method_5875(true);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(DEFINITION_ID, "");
        builder.method_56912(SQUISH_TICK,   0);
    }

    // ── Tick ─────────────────────────────────────────────────────────────────

    @Override
    public void method_5773() {
        super.method_5773();

        prevArmProgress = armProgress;
        prevBobPhase    = bobPhase;

        // ── Arm droop: exponential ease-out ──────────────────────────────────
        // Closes 35 % of the remaining gap each tick.
        if (armProgress < 0.999f) {
            armProgress += (1f - armProgress) * 0.35f;
            if (armProgress > 0.999f) armProgress = 1f;
        }

        // Idle bob — full cycle ≈ 2.5 s at 20 TPS
        bobPhase += 0.08f;

        // Squish timer — server authoritative, client mirrors via TrackedData
        if (!this.method_73183().method_8608()) {
            int st = this.field_6011.method_12789(SQUISH_TICK);
            if (st > 0) this.field_6011.method_12778(SQUISH_TICK, st - 1);
        }
    }

    // ── Interaction (right-click) ─────────────────────────────────────────────

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (!this.method_73183().method_8608()) {
            this.field_6011.method_12778(SQUISH_TICK, SQUISH_DURATION);
            this.method_73183().method_43128(
                    null,
                    this.method_23317(), this.method_23318(), this.method_23321(),
                    class_3417.field_14628,
                    class_3419.field_15254,
                    0.7f,
                    0.9f + this.field_5974.method_43057() * 0.4f
            );
        }
        return class_1269.field_5812;
    }

    // ── Damage / breaking ─────────────────────────────────────────────────────

    /**
     * Any hit destroys the plushie and drops the item — "breakable like wool."
     * Creative players delete it silently, matching vanilla block behaviour.
     */
    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        if (this.method_64421(source)) {
            return false;
        }

        if (!(source.method_5529() instanceof class_1657 player && player.method_68878())) {
            PlushyDefinition def = getDefinition();
            if (def != null) {
                class_1792 item = PlushyRegistry.getItem(def.getId());
                if (item != null) {
                    this.method_5775(world, new class_1799(item));
                }
            }
        }
        this.method_31472();
        return true;
    }

    // ── Collision / interaction flags ─────────────────────────────────────────

    /** Other entities are blocked by this one; shape = EntityType AABB. */
    @Override
    public boolean method_30948(@Nullable class_1297 entity) {
        return true;
    }
    /** Cannot be pushed or knocked by anything. */
    @Override
    public boolean method_5810() {
        return false;
    }
    /** Needed so the client sends an attack packet → triggers damage() server-side. */
    @Override
    public boolean method_5732() {
        return true;
    }
    /** Arrows / thrown items pass straight through. */
    @Override
    public boolean method_49108() {
        return false;
    }

    // ── Definition / squish access ────────────────────────────────────────────

    public void setDefinitionId(String id) {
        this.field_6011.method_12778(DEFINITION_ID, id);
    }

    public String getDefinitionId() {
        return this.field_6011.method_12789(DEFINITION_ID);
    }

    public PlushyDefinition getDefinition() {
        String raw = this.field_6011.method_12789(DEFINITION_ID);
        return raw.isEmpty() ? null : PlushyRegistry.getDefinition(raw);
    }

    /**
     * 1.0 right after a right-click, counting smoothly down to 0.0 over
     * {@link #SQUISH_DURATION} ticks. Used by the renderer to drive the
     * squeeze scale transform.
     */
    public float getSquishNorm() {
        return this.field_6011.method_12789(SQUISH_TICK) / (float) SQUISH_DURATION;
    }

    // ── NBT (custom data) ────────────────────────────────────────────────────

    @Override
    protected void method_5749(class_11368 view) {
        Optional<String> defId = view.method_71426("DefinitionId", Codec.STRING);
        this.setDefinitionId(defId.orElse(""));
    }

    @Override
    protected void method_5652(class_11372 view) {
        view.method_71468("DefinitionId", Codec.STRING, this.getDefinitionId());
    }
}