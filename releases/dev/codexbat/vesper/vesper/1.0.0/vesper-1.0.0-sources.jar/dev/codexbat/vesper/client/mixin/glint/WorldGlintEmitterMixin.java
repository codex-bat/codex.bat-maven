package dev.codexbat.vesper.client.mixin.glint;

import dev.codexbat.vesper.api.glint.GlintDefinition;
import dev.codexbat.vesper.api.glint.VesperGlintRegistry;
import dev.codexbat.vesper.client.glint.internal.render.WorldGlintParticleManager;
import dev.codexbat.vesper.api.glint.type.AmbientGlint;
import dev.codexbat.vesper.api.glint.type.SparkleGlint;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_5498;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * All offsets passed to emitForStack() are from the entity's FEET (getY())
 * in world-axis-aligned space. WorldGlintParticle adds these to the entity's
 * interpolated position each render frame, so particles track the entity
 * regardless of camera position or movement.
 *
 * The offset is baked at spawn time in world-axis space based on the entity's
 * current yaw/pitch. Rotation between ticks produces minor drift for old
 * particles, but with short lifetimes (~7 ticks) this is imperceptible.
 */
@Mixin(class_638.class)
public class WorldGlintEmitterMixin {

    @Inject(method = "tickEntities", at = @At("TAIL"))
    private void vesper$emitWorldGlintParticles(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        class_638 world = (class_638) (Object) this;

        for (class_1657 player : world.method_18456()) {
            emitHeldItems(client, player);
            emitArmorItems(player);
        }

        for (class_1542 itemEntity : world.method_8390(
                class_1542.class,
                client.field_1724.method_5829().method_1014(32.0),
                e -> true)) {
            // 0.25 above feet centres on the floating item model.
            emitForStack(itemEntity.method_6983(), itemEntity, 0.0, 0.25, 0.0);
        }
    }

    private static void emitHeldItems(class_310 client, class_1657 player) {
        boolean isLocalPlayer = player.method_5667().equals(client.field_1724.method_5667());
        boolean isFirstPerson = client.field_1690.method_31044() == class_5498.field_26664;

        if (isLocalPlayer && isFirstPerson) {
            emitHeldItemsFirstPerson(client.field_1724);
        } else {
            emitHeldItemsThirdPerson(player);
        }
    }

    // -------------------------------------------------------------------------
    // FIRST-PERSON
    // -------------------------------------------------------------------------

    /**
     * All Y values are relative to player feet. getEyeHeight(pose) is
     * pose-aware: 1.62 standing, ~1.27 crouching, ~0.4 swimming/gliding.
     *
     * SWIMMING / GLIDING: the camera tilts to follow the look direction and
     * the arms extend forward, so we project along the 3D look vector.
     *
     * STANDING / CROUCHING: the hand is screen-anchored, not world-projected.
     * We use flat XZ forward + XZ lateral. Grip drop is pitch-based: looking
     * down raises the hand on screen (smaller drop); looking up lowers it.
     */
    private static void emitHeldItemsFirstPerson(class_746 player) {
        class_4050 pose = player.method_18376();

        float yawRad = (float) Math.toRadians(player.method_36454());
        float sinYaw = (float) Math.sin(yawRad);
        float cosYaw = (float) Math.cos(yawRad);

        // Pose-aware eye height above feet.
        float eyeHeight = player.method_18381(pose);

        if (pose == class_4050.field_18079 || pose == class_4050.field_18077) {
            emitHeldItemsFirstPersonProne(player, sinYaw, cosYaw, eyeHeight);
            return;
        }

        // Standard upright first-person.
        float pitch        = player.method_36455();
        float pitchClamped = Math.max(-90f, Math.min(90f, pitch));
        float pitchBlend   = (pitchClamped + 90f) / 180f; // 0=up, 0.5=horizon, 1=down

        // Grip drop from eye level:
        //   pitch -90 (up):   0.50
        //   pitch   0 (horiz):0.30
        //   pitch +90 (down): 0.05
        double gripDrop = 0.50 - (0.45 * pitchBlend);

        double fwdDist = 0.35;
        double fwdX    = -sinYaw * fwdDist;
        double fwdZ    =  cosYaw * fwdDist;

        float downFrac = Math.max(0f, pitchClamped / 90f);

        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) continue;

            boolean isMainHand  = hand == class_1268.field_5808;
            boolean rightHanded = player.method_6068() == class_1306.field_6183;
            double  lateralSign = (isMainHand == rightHanded) ? 1.0 : -1.0;

            // Lateral collapses slightly when looking straight down.
            double latDist = 0.38 - (0.12 * downFrac);
            double latX    = -cosYaw * latDist * lateralSign;
            double latZ    = -sinYaw * latDist * lateralSign;

            emitForStack(stack, player,
                    fwdX + latX,
                    eyeHeight - gripDrop,  // from player feet
                    fwdZ + latZ);
        }
    }

    /**
     * First-person prone (SWIMMING or GLIDING).
     *
     * Camera tilts to follow look direction; arms extend forward along the
     * 3D look vector from the body centre. Lateral collapses toward zero
     * as pitch steepens (hands converge ahead of the body when diving).
     */
    private static void emitHeldItemsFirstPersonProne(
            class_746 player,
            float sinYaw, float cosYaw,
            float eyeHeight) {

        float pitchRad = (float) Math.toRadians(player.method_36455());
        float sinPitch = (float) Math.sin(pitchRad);
        float cosPitch = (float) Math.cos(pitchRad);

        float pitch        = player.method_36455();
        float pitchClamped = Math.max(-90f, Math.min(90f, pitch));
        float downFrac     = Math.max(0f, pitchClamped / 90f);

        // Arms reach 0.5 blocks forward along the full 3D look direction.
        double fwdDist     = 0.50;
        double fwdX        = -sinYaw * cosPitch * fwdDist;
        double fwdYOffset  = -sinPitch * fwdDist; // vertical component of reach
        double fwdZ        =  cosYaw * cosPitch * fwdDist;

        // Lateral is minimal (arms converge forward when swimming).
        // Collapses further when looking straight down.
        double latDist = 0.15 * (1.0 - downFrac * 0.8);

        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) continue;

            boolean isMainHand  = hand == class_1268.field_5808;
            boolean rightHanded = player.method_6068() == class_1306.field_6183;
            double  lateralSign = (isMainHand == rightHanded) ? 1.0 : -1.0;

            double latX = -cosYaw * latDist * lateralSign;
            double latZ = -sinYaw * latDist * lateralSign;

            emitForStack(stack, player,
                    fwdX + latX,
                    eyeHeight + fwdYOffset,  // from player feet
                    fwdZ + latZ);
        }
    }

    // -------------------------------------------------------------------------
    // THIRD-PERSON / REMOTE PLAYERS
    // -------------------------------------------------------------------------

    private static void emitHeldItemsThirdPerson(class_1657 player) {
        switch (player.method_18376()) {
            case field_18079    -> emitHeldItemsProne(player, false); // swimming + crawling
            case field_18077     -> emitHeldItemsProne(player, true);  // elytra
            case field_18080 -> emitHeldItemsRiptide(player);
            case field_18078    -> emitHeldItemsSleeping(player);
            case field_18081   -> emitHeldItemsUpright(player, true);
            default          -> emitHeldItemsUpright(player, false);
        }
    }

    /**
     * Upright pose (standing or crouching). All offsets are from entity feet.
     * Uses getBodyYaw() so the hand position tracks the body, not the head,
     * matching what is visible in third-person.
     */
    private static void emitHeldItemsUpright(class_1657 player, boolean crouching) {
        float yawRad = (float) Math.toRadians(player.method_73188());
        float sinYaw = (float) Math.sin(yawRad);
        float cosYaw = (float) Math.cos(yawRad);

        double heightFraction = crouching ? 0.52 : 0.62;
        double offsetY        = player.method_17682() * heightFraction; // from feet

        // Crouching model leans slightly forward.
        double forwardBias = crouching ? 0.12 : 0.0;
        double biasX       = -sinYaw * forwardBias;
        double biasZ       =  cosYaw * forwardBias;

        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) continue;

            boolean isMainHand  = hand == class_1268.field_5808;
            boolean rightHanded = player.method_6068() == class_1306.field_6183;
            double  lateralSign = (isMainHand == rightHanded) ? 1.0 : -1.0;

            double offsetX = biasX + (-sinYaw * 0.20) + (-cosYaw * 0.30 * lateralSign);
            double offsetZ = biasZ + ( cosYaw * 0.20) + (-sinYaw * 0.30 * lateralSign);

            emitForStack(stack, player, offsetX, offsetY, offsetZ);
        }
    }

    /**
     * Prone pose (SWIMMING / crawling, GLIDING). Body is horizontal along
     * the 3D look vector. Offsets are from entity feet in world-axis space.
     *
     * The "right" vector (arm lateral) is the XZ perpendicular to yaw and
     * is pitch-independent — arms stay to the body's sides regardless of
     * dive angle.
     */
    private static void emitHeldItemsProne(class_1657 player, boolean foldedArms) {
        float yawRad   = (float) Math.toRadians(player.method_36454());
        float pitchRad = (float) Math.toRadians(player.method_36455());
        float sinYaw   = (float) Math.sin(yawRad);
        float cosYaw   = (float) Math.cos(yawRad);
        float sinPitch = (float) Math.sin(pitchRad);
        float cosPitch = (float) Math.cos(pitchRad);

        // Body centre: height is compressed (0.6 when swimming/gliding).
        double bodyCentreY = player.method_17682() * 0.5;

        // Forward (3D look direction) and right (XZ perpendicular) vectors.
        double fwdX    = -sinYaw * cosPitch;
        double fwdY    = -sinPitch;
        double fwdZ    =  cosYaw * cosPitch;
        double rightX  = -cosYaw; // player's right in XZ
        double rightZ  = -sinYaw;

        double fwdReach = foldedArms ? 0.10 : 0.25;
        double latReach = foldedArms ? 0.10 : 0.22;

        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) continue;

            boolean isMainHand  = hand == class_1268.field_5808;
            boolean rightHanded = player.method_6068() == class_1306.field_6183;
            double  lateralSign = (isMainHand == rightHanded) ? 1.0 : -1.0;

            emitForStack(stack, player,
                    fwdX * fwdReach + rightX * latReach * lateralSign,
                    bodyCentreY + fwdY * fwdReach,
                    fwdZ * fwdReach + rightZ * latReach * lateralSign);
        }
    }

    private static void emitHeldItemsRiptide(class_1657 player) {
        float yawRad = (float) Math.toRadians(player.method_36454());
        float sinYaw = (float) Math.sin(yawRad);
        float cosYaw = (float) Math.cos(yawRad);

        class_1799 main = player.method_6047();
        if (!main.method_7960()) {
            emitForStack(main, player,
                    -sinYaw * 0.5,
                    player.method_17682() * 0.70,
                    cosYaw * 0.5);
        }
    }

    private static void emitHeldItemsSleeping(class_1657 player) {
        float yawRad = (float) Math.toRadians(player.method_36454());
        float sinYaw = (float) Math.sin(yawRad);
        float cosYaw = (float) Math.cos(yawRad);

        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) continue;

            boolean isMainHand  = hand == class_1268.field_5808;
            boolean rightHanded = player.method_6068() == class_1306.field_6183;
            double  lateralSign = (isMainHand == rightHanded) ? 1.0 : -1.0;

            emitForStack(stack, player,
                    (-sinYaw * 0.35) + (-cosYaw * 0.18 * lateralSign),
                    0.3,  // above entity feet (bed surface height)
                    ( cosYaw * 0.35) + (-sinYaw * 0.18 * lateralSign));
        }
    }

    // -------------------------------------------------------------------------
    // ARMOUR
    // -------------------------------------------------------------------------

    private static void emitArmorItems(class_1309 entity) {
        class_4050 pose   = entity.method_18376();
        boolean    prone  = pose == class_4050.field_18079 || pose == class_4050.field_18077;

        float yawRad   = (float) Math.toRadians(entity.method_36454());
        float pitchRad = prone ? (float) Math.toRadians(entity.method_36455()) : 0f;
        float sinYaw   = (float) Math.sin(yawRad);
        float cosYaw   = (float) Math.cos(yawRad);
        float sinPitch = (float) Math.sin(pitchRad);
        float cosPitch = prone ? (float) Math.cos(pitchRad) : 1f;

        double bodyHeight = entity.method_17682();

        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5925() != class_1304.class_1305.field_6178) continue;

            class_1799 stack = entity.method_6118(slot);
            if (stack.method_7960()) continue;

            double fraction = switch (slot) {
                case field_6166  -> 0.10;
                case field_6172  -> 0.35;
                case field_6174 -> 0.65;
                case field_6169  -> 0.90;
                default    -> 0.50;
            };

            if (!prone) {
                double sneakOffset = (pose == class_4050.field_18081) ? -0.08 : 0.0;
                emitForStack(stack, entity,
                        0.0,
                        bodyHeight * fraction + sneakOffset,
                        0.0);
            } else {
                // Map slot fraction to position along the body spine.
                // fraction 0.9 (head) → front; 0.1 (feet) → tail.
                double along = fraction - 0.5; // -0.4 to +0.4
                emitForStack(stack, entity,
                        -sinYaw * cosPitch * along,
                        bodyHeight * 0.5 + (-sinPitch * along),
                        cosYaw * cosPitch * along);
            }
        }
    }

    // -------------------------------------------------------------------------
    // SHARED
    // -------------------------------------------------------------------------

    private static void emitForStack(class_1799 stack, class_1297 entity,
                                     double offsetX, double offsetY, double offsetZ) {
        if (stack.method_7960() || entity.method_31481()) return;

        Optional<GlintDefinition> opt = VesperGlintRegistry.getGlint(stack.method_7909());
        if (opt.isEmpty()) return;

        GlintDefinition def = opt.get();
        if (!def.hasWorldParticles()) return;

        if (def instanceof AmbientGlint ambient) {
            WorldGlintParticleManager.spawn(entity, offsetX, offsetY, offsetZ, ambient.getConfig());
        } else if (def instanceof SparkleGlint sparkle) {
            WorldGlintParticleManager.spawn(entity, offsetX, offsetY, offsetZ, sparkle.getWorldConfig());
        }
    }
}