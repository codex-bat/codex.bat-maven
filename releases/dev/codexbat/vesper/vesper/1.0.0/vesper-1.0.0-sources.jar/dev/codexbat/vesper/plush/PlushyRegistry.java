package dev.codexbat.vesper.plush;

import dev.codexbat.vesper.plush.block.PlushyBlock;
import dev.codexbat.vesper.plush.block.entity.PlushyBlockEntity;
import dev.codexbat.vesper.plush.entity.PlushyEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Calling PlushyRegistry.initialize() once in common mod initializer,
 * then PlushyRegistry.register(definition) for each plushie.
 */
public final class PlushyRegistry {

    public static class_2248 PLUSHY_BLOCK;
    public static class_2591<PlushyBlockEntity> PLUSHY_BLOCK_ENTITY;

    private static final Map<class_2960, PlushyDefinition> DEFINITIONS = new HashMap<>();
    private static final Map<class_2960, class_1792>             ITEMS       = new HashMap<>();
    private static class_1299<PlushyEntity> ENTITY_TYPE;

    public static class_1299<PlushyEntity> getEntityType() {
        if (ENTITY_TYPE == null) throw new IllegalStateException("Call PlushyRegistry.initialize() first");
        return ENTITY_TYPE;
    }

    /** Register the shared entity type. Vesper calls this; you do not need to. */
    public static void initialize() {
        if (PLUSHY_BLOCK != null) {
            return;
        }

        class_2960 id = class_2960.method_60655("vesper", "plushy");
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);

        PLUSHY_BLOCK = class_2378.method_10230(
                class_7923.field_41175,
                id,
                new PlushyBlock(
                        class_4970.class_2251.method_9637()
                                .method_63500(blockKey)
                                .method_9632(0.2f)
                                .method_9626(class_2498.field_11543)
                                .method_22488()
                )
        );

        PLUSHY_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                id,
                FabricBlockEntityTypeBuilder.create(
                        PlushyBlockEntity::new,
                        PLUSHY_BLOCK
                ).build()
        );
    }

    /**
     * Register a plushie. Creates and registers its Item. Returns the item.
     * Called from common ModInitializer, after PlushyRegistry.initialize().
     */
    public static class_1792 register(PlushyDefinition def) {
        class_2960 id = def.getId();
        if (DEFINITIONS.containsKey(id))
            throw new IllegalArgumentException("Plushie already registered: " + id);

        DEFINITIONS.put(id, def);
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);
        PlushyItem item = new PlushyItem(def, new class_1792.class_1793().method_7889(1).method_63686(itemKey));
        class_2378.method_10230(class_7923.field_41178, id, item);
        ITEMS.put(id, item);
        return item;
    }

    public static PlushyDefinition           getDefinition(class_2960 id)  { return DEFINITIONS.get(id); }
    public static PlushyDefinition           getDefinition(String raw)      { return DEFINITIONS.get(class_2960.method_60654(raw)); }
    public static class_1792                       getItem(class_2960 id)         { return ITEMS.get(id); }
    public static Collection<PlushyDefinition> getAllDefinitions()          { return DEFINITIONS.values(); }
}